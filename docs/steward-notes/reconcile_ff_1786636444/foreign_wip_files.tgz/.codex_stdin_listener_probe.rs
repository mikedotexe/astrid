use std::os::fd::AsFd;
use std::os::unix::net::UnixListener;

fn main() {
    let stdin = std::io::stdin();
    let owned = stdin.as_fd().try_clone_to_owned().unwrap();
    let _: UnixListener = owned.into();
}
