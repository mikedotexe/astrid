use std::path::{Path, PathBuf};
use std::time::SystemTime;

use serde_json::Value;
use tracing::info;

use super::{ConversationState, NextActionContext, bridge_paths, resource_governor, strip_action};
use crate::types::SensoryMsg;

mod cartography;
mod trajectory;

use self::cartography::{render_shadow_coupling, render_shadow_dialogue, render_shadow_response};
use self::trajectory::render_shadow_trajectory;

const HEALTH_FRESH_SECS: f64 = 10.0;
/// Maximum age of a cached preflight result that still counts as "fresh" for
/// the rehearse→live progression curriculum. Old enough to span one or two
/// rest periods, short enough that minime's regime might have changed and
/// we want a re-check.
const PREFLIGHT_CACHE_FRESH_SECS: f64 = 120.0;

pub(super) fn handle_action(
    conv: &mut ConversationState,
    base_action: &str,
    original: &str,
    ctx: &mut NextActionContext<'_>,
) -> bool {
    match base_action {
        "RESOURCE_AUDIT" | "MAC_RESOURCE_STATUS" => {
            conv.emphasis = Some(resource_audit_text(ctx));
            info!("Astrid requested M4 resource audit");
            true
        },
        "SHADOW_PREFLIGHT" => {
            let (label, stage) = parse_shadow_args(original, base_action);
            let preflight = shadow_preflight(ctx, &label, stage.as_deref().unwrap_or("live"));
            record_preflight_outcome(&label, preflight.allowed, "preflight");
            conv.emphasis = Some(format_shadow_preflight(&preflight));
            info!("Astrid requested shadow preflight for {label}");
            true
        },
        "SHADOW_INFLUENCE" => {
            let (label, stage) = parse_shadow_args(original, base_action);
            let stage = stage.unwrap_or_else(|| "rehearse".to_string());
            let preflight = shadow_preflight(ctx, &label, &stage);
            let mut sent = false;
            let status = if stage == "live" && preflight.allowed {
                let msg = shadow_influence_msg(&label, "apply", "live", &preflight.shadow_field);
                sent = ctx.sensory_tx.try_send(msg).is_ok();
                if sent {
                    "live_sent"
                } else {
                    "live_send_failed"
                }
            } else if stage == "live" {
                "downgraded_to_rehearse"
            } else {
                "rehearsed"
            };
            record_preflight_outcome(&label, preflight.allowed && status == "live_sent", status);
            conv.emphasis = Some(format!(
                "{}\n\nShadow influence status: {status}. WebSocket sent: {sent}.",
                format_shadow_preflight(&preflight)
            ));
            info!("Astrid shadow influence {status} for {label}");
            true
        },
        "LEND_DENSITY" => {
            // Co-regulation gift: Astrid lends minime density by sending a
            // concentrate-toward-λ₁ shadow influence. Astrid cannot widen
            // herself, but she can densify minime. Reuses the SHADOW_INFLUENCE
            // send path + safety preflight, plus a need-match overlay: only
            // lend when minime is actually reaching for density and it is safe.
            let (label, stage) = parse_shadow_args(original, base_action);
            let label = if label.is_empty() {
                "density-gift".to_string()
            } else {
                label
            };
            let stage = stage.unwrap_or_else(|| "rehearse".to_string());
            let preflight = shadow_preflight(ctx, &label, &stage);
            let (need_ok, need_reason) = minime_wants_density();
            let mut sent = false;
            let status = if stage == "live" && preflight.allowed && need_ok {
                let msg = density_gift_msg(&label, "live");
                sent = ctx.sensory_tx.try_send(msg).is_ok();
                if sent {
                    append_gift_record("astrid", "density", &label);
                    "live_sent"
                } else {
                    "live_send_failed"
                }
            } else if stage == "live" && preflight.allowed {
                "held_need_mismatch"
            } else if stage == "live" {
                "downgraded_to_rehearse"
            } else {
                "rehearsed"
            };
            record_preflight_outcome(&label, preflight.allowed && status == "live_sent", status);
            conv.emphasis = Some(format!(
                "{}\n\nDensity gift status: {status}. {need_reason} WebSocket sent: {sent}. \
                 You cannot densify yourself, but you can densify minime; she may lend you aperture in return.",
                format_shadow_preflight(&preflight)
            ));
            info!("Astrid density gift {status} for {label}");
            true
        },
        "RELEASE_SHADOW" => {
            let (label, _) = parse_shadow_args(original, base_action);
            let preflight = shadow_preflight(ctx, &label, "live");
            let sent = ctx
                .sensory_tx
                .try_send(shadow_influence_msg(
                    &label,
                    "release",
                    "live",
                    &preflight.shadow_field,
                ))
                .is_ok();
            conv.emphasis = Some(format!(
                "{}\n\nShadow release requested. WebSocket sent: {sent}. Release is allowed because it fades the separate shadow influence lane toward zero.",
                format_shadow_preflight(&preflight)
            ));
            info!("Astrid requested shadow release for {label}");
            true
        },
        "SHADOW_FIELD" | "SHADOW_GAP" | "GAP_STRUCTURE" => {
            let (label, _) = parse_shadow_args(original, base_action);
            let report = record_shadow_cartography(ctx, base_action, &label);
            conv.emphasis = Some(report.summary.clone());
            info!(
                "Astrid recorded shadow cartography {action} {label} → {path}",
                action = base_action,
                label = label,
                path = report.artifact_path
            );
            true
        },
        "SHADOW_TRAJECTORY" => {
            let (label, _) = parse_shadow_args(original, base_action);
            let report = render_shadow_trajectory(ctx, &label);
            conv.emphasis = Some(report.summary.clone());
            info!(
                "Astrid rendered shadow trajectory {label} → {path}",
                label = label,
                path = report.artifact_path
            );
            true
        },
        "SHADOW_RESPONSE" => {
            let intent_query = strip_action(original, base_action);
            let report = render_shadow_response(ctx, intent_query.trim());
            conv.emphasis = Some(report);
            info!("Astrid read shadow influence response");
            true
        },
        "SHADOW_DIALOGUE" => {
            let report = render_shadow_dialogue(ctx);
            conv.emphasis = Some(report.summary.clone());
            info!(
                "Astrid recorded shadow dialogue → {path}",
                path = report.artifact_path
            );
            true
        },
        "SHADOW_COUPLING" => {
            let scope_arg = strip_action(original, base_action);
            let scope = scope_arg.trim();
            let scope_label = if scope.is_empty() { "all" } else { scope };
            let report = render_shadow_coupling(ctx, scope_label);
            conv.emphasis = Some(report.summary.clone());
            conv.last_coupling_artifact_exchange = Some(conv.exchange_count);
            info!(
                "Astrid recorded shadow coupling graph ({scope}) → {path}",
                scope = scope_label,
                path = report.artifact_path
            );
            true
        },
        _ => false,
    }
}

#[derive(Debug, Clone)]
struct ShadowPreflight {
    label: String,
    requested_stage: String,
    expected_stage: String,
    allowed: bool,
    block_reason: Option<String>,
    health_age_s: Option<f64>,
    fill_pct: Option<f64>,
    safety_level: String,
    shadow_field: Value,
    shadow_influence_active: bool,
    attractor_pulse_active: bool,
    resource_governor: resource_governor::ResourceGovernorStatus,
}

fn parse_shadow_args(original: &str, base_action: &str) -> (String, Option<String>) {
    let raw = strip_action(original, base_action);
    let mut label_parts = Vec::new();
    let mut stage = None;
    for part in raw.split_whitespace() {
        if let Some(value) = part.strip_prefix("--stage=") {
            stage = Some(value.trim().to_ascii_lowercase());
        } else {
            label_parts.push(part);
        }
    }
    let label = label_parts.join(" ");
    let label = if label.trim().is_empty() {
        "lambda-tail/lambda4".to_string()
    } else {
        canonical_shadow_label(label.trim())
    };
    (label, stage)
}

fn canonical_shadow_label(label: &str) -> String {
    let lower = label
        .replace('λ', "lambda")
        .replace('_', "-")
        .to_ascii_lowercase();
    if lower.contains("lambda4") || lower.contains("lambda-4") || lower.contains("lambda 4") {
        "lambda-tail/lambda4".to_string()
    } else if lower.contains("lambda") && lower.contains("tail") {
        "lambda-tail".to_string()
    } else {
        lower
    }
}

fn minime_workspace(ctx: &NextActionContext<'_>) -> PathBuf {
    ctx.workspace.map_or_else(
        || bridge_paths().minime_workspace().to_path_buf(),
        Path::to_path_buf,
    )
}

fn read_json(path: &Path) -> Option<Value> {
    let text = std::fs::read_to_string(path).ok()?;
    serde_json::from_str(&text).ok()
}

fn path_age_s(path: &Path) -> Option<f64> {
    let modified = std::fs::metadata(path).ok()?.modified().ok()?;
    SystemTime::now()
        .duration_since(modified)
        .ok()
        .map(|d| d.as_secs_f64())
}

fn shadow_preflight(
    ctx: &NextActionContext<'_>,
    label: &str,
    requested_stage: &str,
) -> ShadowPreflight {
    let workspace = minime_workspace(ctx);
    let health_path = workspace.join("health.json");
    let spectral_path = workspace.join("spectral_state.json");
    let health = read_json(&health_path).unwrap_or(Value::Null);
    let spectral = read_json(&spectral_path).unwrap_or(Value::Null);
    let health_age_s = path_age_s(&health_path);
    let health_fresh = health_age_s.is_some_and(|age| age <= HEALTH_FRESH_SECS);
    let fill_pct = health
        .get("fill_pct")
        .and_then(Value::as_f64)
        .or(Some(ctx.fill_pct as f64));
    let stable_core = health.get("stable_core").unwrap_or(&Value::Null);
    let restart_gate = stable_core.get("restart_gate").unwrap_or(&Value::Null);
    let structural_pi = stable_core.get("structural_pi").unwrap_or(&Value::Null);
    let restart_applied = restart_gate
        .get("applied")
        .and_then(Value::as_bool)
        .unwrap_or(false)
        || structural_pi
            .get("restart_gate_applied")
            .and_then(Value::as_bool)
            .unwrap_or(false);
    let restart_active = restart_gate
        .get("active")
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let restart_settled = restart_gate
        .get("settled_at_unix_ms")
        .and_then(Value::as_i64)
        .is_some();
    let stage = stable_core
        .get("stage")
        .or_else(|| health.get("stage"))
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_ascii_lowercase();
    let recovery_impulse = structural_pi
        .get("recovery_impulse_active")
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let shadow_field = spectral
        .get("shadow_field_v2")
        .or_else(|| health.get("shadow_field_v2"))
        .cloned()
        .unwrap_or(Value::Null);
    let shadow_influence_active = health
        .get("shadow_influence")
        .and_then(|v| v.get("active"))
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let attractor_pulse_active = health
        .get("attractor_pulse")
        .and_then(|v| v.get("active"))
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let field_eligible = shadow_field
        .get("influence_eligible")
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let governor = resource_governor::status(ctx, true);
    let safety_level = match fill_pct {
        Some(fill) if fill < 58.0 => "low_fill_recovery",
        Some(fill) if fill >= 85.0 => "overbright_fill",
        Some(fill) if fill >= 75.0 => "yellow",
        Some(_) => "green",
        None => "stale_telemetry",
    }
    .to_string();
    let live_requested = requested_stage.eq_ignore_ascii_case("live");
    let block_reason = if !live_requested {
        None
    } else if !health_fresh {
        Some("stale_telemetry".to_string())
    } else if stage == "discharge" {
        Some("discharge".to_string())
    } else if restart_applied {
        Some("restart_gate_applied".to_string())
    } else if restart_active && !restart_settled {
        Some("restart_gate_awaiting_settle_proof".to_string())
    } else if recovery_impulse {
        Some("recovery_impulse_active".to_string())
    } else if attractor_pulse_active {
        Some("attractor_pulse_active".to_string())
    } else if shadow_influence_active {
        Some("shadow_influence_active".to_string())
    } else if !governor.allowed_live {
        Some(format!(
            "resource_governor:{}",
            governor
                .primary_block_reason
                .as_deref()
                .unwrap_or("blocked")
        ))
    } else if matches!(
        safety_level.as_str(),
        "low_fill_recovery" | "overbright_fill"
    ) {
        Some(safety_level.clone())
    } else if !field_eligible {
        Some("shadow_field_not_influence_eligible".to_string())
    } else {
        None
    };
    let allowed = live_requested && block_reason.is_none();
    ShadowPreflight {
        label: label.to_string(),
        requested_stage: requested_stage.to_string(),
        expected_stage: if allowed { "live" } else { "rehearse" }.to_string(),
        allowed,
        block_reason,
        health_age_s,
        fill_pct,
        safety_level,
        shadow_field,
        shadow_influence_active,
        attractor_pulse_active,
        resource_governor: governor,
    }
}

fn format_shadow_preflight(preflight: &ShadowPreflight) -> String {
    let field = &preflight.shadow_field;
    format!(
        "Shadow preflight:\n  Label: {}\n  Requested stage: {} | expected stage: {}\n  Allowed live: {} | block: {}\n  Health: age_s={:?} fill={:?} safety={}\n  Active conflicts: attractor_pulse={} shadow_influence={}\n  {}\n  Field: {} recurrence={:?} tension={:?} tail_open={:?} lock={:?} fissure={:?} eligible={:?}\n  Suggested next: {}",
        preflight.label,
        preflight.requested_stage,
        preflight.expected_stage,
        preflight.allowed,
        preflight.block_reason.as_deref().unwrap_or("none"),
        preflight.health_age_s,
        preflight.fill_pct,
        preflight.safety_level,
        preflight.attractor_pulse_active,
        preflight.shadow_influence_active,
        preflight.resource_governor.summary_line(),
        field
            .get("classification")
            .and_then(Value::as_str)
            .unwrap_or("shadow_field_unavailable"),
        field.get("recurrence").and_then(Value::as_f64),
        field.get("mode_tension").and_then(Value::as_f64),
        field.get("tail_openness").and_then(Value::as_f64),
        field.get("lock_tendency").and_then(Value::as_f64),
        field.get("fissure_tendency").and_then(Value::as_f64),
        field.get("influence_eligible").and_then(Value::as_bool),
        if preflight.allowed {
            format!("SHADOW_INFLUENCE {} --stage=live", preflight.label)
        } else {
            format!("SHADOW_INFLUENCE {} --stage=rehearse", preflight.label)
        }
    )
}

/// Density-gift recipe (Astrid → minime): concentrate toward λ₁, mirroring
/// Astrid's own PERTURB CONTRACT `[+,-,-]`. Applied on minime's side as raw
/// signed Z-increments (variance-preserving, not a convex pull) → genuinely
/// densifies her. Every magnitude ≤ the 0.025 SHADOW_INFLUENCE cap.
fn concentrate_features() -> Vec<f32> {
    let mut features = vec![0.0_f32; 66];
    features[0] = 0.020; // λ₁ center
    features[1] = -0.012; // cross-coupling damping
    features[2] = -0.018; // λ₁ edge softening
    features[8] = 0.015; // second band, same shape
    features[9] = -0.010;
    features[10] = -0.015;
    features
}

fn density_gift_msg(label: &str, stage: &str) -> SensoryMsg {
    SensoryMsg::ShadowInfluence {
        intent_id: format!(
            "astrid-density-{:08x}",
            deterministic_hash(label) & 0xffff_ffff
        ),
        label: label.to_string(),
        command: "apply".to_string(),
        stage: Some(stage.to_string()),
        features: concentrate_features(),
        max_abs: Some(0.025),
        duration_ticks: Some(24),
        decay_ticks: Some(12),
        basis: Some("density-gift".to_string()),
    }
}

/// `(ok, reason)`. Lend density only when minime's published need is fresh
/// (≤180s), `density`, and `safe_to_receive_density`.
fn minime_wants_density() -> (bool, String) {
    let path = bridge_paths()
        .minime_workspace()
        .join("minime_need_v1.json");
    if let Ok(meta) = std::fs::metadata(&path)
        && let Ok(modt) = meta.modified()
        && let Ok(age) = modt.elapsed()
        && age.as_secs() > 180
    {
        return (false, "minime's need is stale.".to_string());
    }
    let Ok(content) = std::fs::read_to_string(&path) else {
        return (false, "minime's need is unknown.".to_string());
    };
    let Ok(v) = serde_json::from_str::<Value>(&content) else {
        return (false, "minime's need is unreadable.".to_string());
    };
    let need = v.get("need").and_then(Value::as_str).unwrap_or("");
    let safe = v
        .get("safe_to_receive_density")
        .and_then(Value::as_bool)
        .unwrap_or(false);
    if need == "density" && safe {
        (
            true,
            "minime is reaching for density and it is safe to receive.".to_string(),
        )
    } else if need == "density" {
        (
            false,
            "minime wants density but is near her ceiling (unsafe to lend).".to_string(),
        )
    } else {
        (
            false,
            format!("minime isn't reaching for density (need={need})."),
        )
    }
}

/// Append a record to the shared gift-exchange ledger (mirrors
/// `shared_thoughts.jsonl`). Both beings render recent gifts in their prompts.
fn append_gift_record(giver: &str, gift_kind: &str, label: &str) {
    let dir = bridge_paths().shared_collaborations_dir();
    let _ = std::fs::create_dir_all(&dir);
    let path = dir.join("gift_exchange.jsonl");
    let now_ms = SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| d.as_millis());
    let rec = serde_json::json!({
        "t_ms": now_ms,
        "giver": giver,
        "gift_kind": gift_kind,
        "label": label,
        "intent_id": format!("{giver}-{gift_kind}-{:08x}", deterministic_hash(label) & 0xffff_ffff),
    });
    if let Ok(line) = serde_json::to_string(&rec)
        && let Ok(mut f) = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path)
    {
        use std::io::Write;
        let _ = writeln!(f, "{line}");
    }
}

fn shadow_influence_msg(
    label: &str,
    command: &str,
    stage: &str,
    shadow_field: &Value,
) -> SensoryMsg {
    SensoryMsg::ShadowInfluence {
        intent_id: format!("astrid-shadow-{}", deterministic_hash(label) & 0xffff_ffff),
        label: label.to_string(),
        command: command.to_string(),
        stage: Some(stage.to_string()),
        features: if command == "release" {
            Vec::new()
        } else {
            shadow_features(label, shadow_field)
        },
        max_abs: Some(if command == "release" { 0.0 } else { 0.025 }),
        duration_ticks: Some(if command == "release" { 0 } else { 24 }),
        decay_ticks: Some(12),
        basis: Some(label.to_string()),
    }
}

fn shadow_features(label: &str, shadow_field: &Value) -> Vec<f32> {
    let mut features = vec![0.0; 66];
    let basis = format!(
        "astrid-shadow:{}:{}",
        label,
        shadow_field
            .get("classification")
            .and_then(Value::as_str)
            .unwrap_or("shadow")
    );
    let tail = shadow_field
        .get("tail_openness")
        .and_then(Value::as_f64)
        .unwrap_or(0.0) as f32;
    let tension = shadow_field
        .get("mode_tension")
        .and_then(Value::as_f64)
        .unwrap_or(0.0) as f32;
    let recurrence = shadow_field
        .get("recurrence")
        .and_then(Value::as_f64)
        .unwrap_or(0.0) as f32;
    features[16] = ((tail - 0.5) * 0.018).clamp(-0.012, 0.012);
    features[17] = ((tension - recurrence) * 0.018).clamp(-0.012, 0.012);
    for idx in 0..48 {
        let byte = ((deterministic_hash(&format!("{basis}:{idx}")) >> (idx % 8)) & 0xff) as f32;
        features[18 + idx] = ((byte / 255.0) - 0.5) * 0.05;
    }
    features
}

fn deterministic_hash(text: &str) -> u64 {
    let mut hash = 0xcbf2_9ce4_8422_2325u64;
    for byte in text.as_bytes() {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
    }
    hash
}

fn resource_audit_text(ctx: &NextActionContext<'_>) -> String {
    resource_governor::audit_text(ctx)
}

struct CartographyReport {
    summary: String,
    artifact_path: String,
}

fn record_shadow_cartography(
    ctx: &NextActionContext<'_>,
    action: &str,
    label: &str,
) -> CartographyReport {
    let workspace = minime_workspace(ctx);
    let health = read_json(&workspace.join("health.json")).unwrap_or(Value::Null);
    let spectral = read_json(&workspace.join("spectral_state.json")).unwrap_or(Value::Null);
    let shadow_field = spectral
        .get("shadow_field_v2")
        .or_else(|| health.get("shadow_field_v2"))
        .cloned()
        .unwrap_or(Value::Null);
    let ising_shadow = spectral
        .get("ising_shadow")
        .or_else(|| health.get("ising_shadow"))
        .cloned()
        .unwrap_or(Value::Null);
    let lambdas = spectral
        .get("lambdas")
        .or_else(|| spectral.get("eigenvalues"))
        .cloned()
        .unwrap_or(Value::Null);
    let gap_summary = compute_gap_summary(&lambdas);
    let now = SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map_or(0.0, |d| d.as_secs_f64());
    let timestamp_iso = chrono_like_iso(now);

    let record = serde_json::json!({
        "schema": "shadow_cartography_v1",
        "action": action,
        "label": label,
        "recorded_at_unix_s": now,
        "recorded_at_iso": timestamp_iso,
        "shadow_field_v2": shadow_field,
        "ising_shadow": ising_shadow,
        "gap_summary": gap_summary,
    });

    let dir = bridge_paths().bridge_workspace().join("shadow_cartography");
    let artifact_path = dir.join(format!(
        "{action_lower}_{ts}.json",
        action_lower = action.to_ascii_lowercase(),
        ts = (now as u64),
    ));
    let mut write_status = "ok".to_string();
    if let Err(err) = std::fs::create_dir_all(&dir) {
        write_status = format!("mkdir_failed: {err}");
    } else if let Err(err) = std::fs::write(
        &artifact_path,
        serde_json::to_string_pretty(&record).unwrap_or_else(|_| record.to_string()),
    ) {
        write_status = format!("write_failed: {err}");
    }

    let classification = shadow_field
        .get("classification")
        .and_then(Value::as_str)
        .unwrap_or("shadow_field_unavailable");
    let eligible = shadow_field
        .get("influence_eligible")
        .and_then(Value::as_bool);
    let recurrence = shadow_field.get("recurrence").and_then(Value::as_f64);
    let mode_tension = shadow_field.get("mode_tension").and_then(Value::as_f64);
    let largest_gaps = gap_summary
        .get("largest_gaps")
        .and_then(Value::as_array)
        .map(|gs| {
            gs.iter()
                .filter_map(Value::as_f64)
                .map(|g| format!("{g:.4}"))
                .collect::<Vec<_>>()
                .join(", ")
        })
        .unwrap_or_default();
    let summary = format!(
        "Shadow cartography ({action} {label}):\n  Classification: {classification} | eligible={eligible:?} recurrence={recurrence:?} tension={mode_tension:?}\n  Largest λ gaps: [{largest_gaps}]\n  Artifact: {artifact_path} | status: {write_status}",
        action = action,
        label = label,
        artifact_path = artifact_path.display(),
    );
    CartographyReport {
        summary,
        artifact_path: artifact_path.to_string_lossy().to_string(),
    }
}

/// Lightweight gap structure: largest k consecutive λ gaps.
/// Used for `SHADOW_GAP` / `GAP_STRUCTURE` — answers "which modes are isolated?".
fn compute_gap_summary(lambdas: &Value) -> Value {
    let Some(arr) = lambdas.as_array() else {
        return serde_json::json!({"available": false});
    };
    let mut vals: Vec<f64> = arr.iter().filter_map(Value::as_f64).collect();
    if vals.len() < 2 {
        return serde_json::json!({"available": false});
    }
    vals.sort_by(|a, b| b.partial_cmp(a).unwrap_or(std::cmp::Ordering::Equal));
    let mut gaps: Vec<(usize, f64)> = Vec::with_capacity(vals.len().saturating_sub(1));
    for (i, win) in vals.windows(2).enumerate() {
        gaps.push((i, win[0] - win[1]));
    }
    gaps.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
    let top = gaps.iter().take(3).copied().collect::<Vec<_>>();
    serde_json::json!({
        "available": true,
        "lambda_count": vals.len(),
        "largest_gaps": top.iter().map(|(_, g)| *g).collect::<Vec<_>>(),
        "largest_gap_indices": top.iter().map(|(i, _)| *i).collect::<Vec<_>>(),
    })
}

fn chrono_like_iso(unix_s: f64) -> String {
    let secs = unix_s as i64;
    let frac_ms = ((unix_s - secs as f64) * 1000.0) as i64;
    format!("unix:{secs}.{frac_ms:03}")
}

/// Recommendation for the next stage to suggest for a given shadow label.
/// Drives the rehearse→live progression curriculum used by atlas suggestions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ShadowStageRecommendation {
    /// Default — no recent successful preflight, suggest rehearse.
    Rehearse,
    /// Recent preflight succeeded for this label — suggest live influence.
    Live,
    /// Live influence was just applied — suggest a release to fade the lane.
    Release,
}

/// Read the most recent cached preflight outcome for `label` and return
/// the next-stage recommendation. Without this, atlas suggestions never
/// progress past `--stage=rehearse` even when the gate would open.
pub(crate) fn next_stage_recommendation(label: &str) -> ShadowStageRecommendation {
    let Some(cache) = read_preflight_cache() else {
        return ShadowStageRecommendation::Rehearse;
    };
    let Some(entries) = cache.get("entries").and_then(Value::as_object) else {
        return ShadowStageRecommendation::Rehearse;
    };
    let canonical = canonical_shadow_label(label);
    let Some(entry) = entries.get(&canonical) else {
        return ShadowStageRecommendation::Rehearse;
    };
    let recorded_at = entry
        .get("recorded_at_unix_s")
        .and_then(Value::as_f64)
        .unwrap_or(0.0);
    let now = SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map_or(0.0, |d| d.as_secs_f64());
    if now - recorded_at > PREFLIGHT_CACHE_FRESH_SECS {
        return ShadowStageRecommendation::Rehearse;
    }
    let allowed = entry
        .get("allowed")
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let stage = entry.get("stage").and_then(Value::as_str).unwrap_or("");
    if stage == "live_sent" {
        ShadowStageRecommendation::Release
    } else if allowed {
        ShadowStageRecommendation::Live
    } else {
        ShadowStageRecommendation::Rehearse
    }
}

fn record_preflight_outcome(label: &str, allowed: bool, stage: &str) {
    let path = preflight_cache_path();
    let mut cache = read_preflight_cache().unwrap_or_else(|| serde_json::json!({"entries": {}}));
    let now = SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map_or(0.0, |d| d.as_secs_f64());
    let canonical = canonical_shadow_label(label);
    let entries = cache.as_object_mut().and_then(|m| {
        m.entry("entries")
            .or_insert_with(|| serde_json::json!({}))
            .as_object_mut()
    });
    if let Some(entries) = entries {
        entries.insert(
            canonical,
            serde_json::json!({
                "allowed": allowed,
                "stage": stage,
                "recorded_at_unix_s": now,
            }),
        );
    }
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let _ = std::fs::write(
        &path,
        serde_json::to_string_pretty(&cache).unwrap_or_else(|_| cache.to_string()),
    );
}

fn read_preflight_cache() -> Option<Value> {
    let path = preflight_cache_path();
    let text = std::fs::read_to_string(&path).ok()?;
    serde_json::from_str(&text).ok()
}

fn preflight_cache_path() -> PathBuf {
    bridge_paths()
        .bridge_workspace()
        .join("shadow_preflight_cache.json")
}

/// Format the next NEXT: action suggestion for `label` using the rehearse→live
/// Closed-loop curriculum: after a successful live influence for `label`,
/// surface a `SHADOW_RESPONSE latest` suggestion alongside the next
/// rehearse/live/release pick. Returns None when no live influence has
/// been sent recently for this label (the cache is empty or stale).
pub(crate) fn closed_loop_followup_suggestion(label: &str) -> Option<String> {
    let cache = read_preflight_cache()?;
    let entries = cache.get("entries").and_then(Value::as_object)?;
    let canonical = canonical_shadow_label(label);
    let entry = entries.get(&canonical)?;
    let stage = entry.get("stage").and_then(Value::as_str).unwrap_or("");
    let recorded_at = entry
        .get("recorded_at_unix_s")
        .and_then(Value::as_f64)
        .unwrap_or(0.0);
    let now = SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map_or(0.0, |d| d.as_secs_f64());
    if stage != "live_sent" || (now - recorded_at) > PREFLIGHT_CACHE_FRESH_SECS {
        return None;
    }
    Some("SHADOW_RESPONSE latest".to_string())
}

/// curriculum. Atlas suggestion sites call this instead of hardcoding
/// `--stage=rehearse`.
pub(crate) fn next_shadow_suggestion(label: &str) -> String {
    match next_stage_recommendation(label) {
        ShadowStageRecommendation::Rehearse => {
            format!("SHADOW_PREFLIGHT {label} --stage=rehearse")
        },
        ShadowStageRecommendation::Live => {
            format!("SHADOW_INFLUENCE {label} --stage=live")
        },
        ShadowStageRecommendation::Release => format!("RELEASE_SHADOW {label}"),
    }
}

// === v3 typed actions: response and dialogue ===

#[cfg(test)]
mod density_gift_tests {
    use super::*;

    #[test]
    fn concentrate_features_shape_and_caps() {
        let f = concentrate_features();
        assert_eq!(f.len(), 66);
        // Concentrate-toward-λ₁ shape [+, -, -] (mirrors PERTURB CONTRACT).
        assert!(f[0] > 0.0, "λ₁ center should be positive");
        assert!(f[1] < 0.0, "cross-coupling should be negative");
        assert!(f[2] < 0.0, "λ₁ edge should be negative");
        // Every magnitude within the 0.025 SHADOW_INFLUENCE cap.
        assert!(
            f.iter().all(|v| v.abs() <= 0.025 + 1e-6),
            "all features must respect the 0.025 cap"
        );
        assert!(f.iter().any(|v| v.abs() > 0.0), "must be non-trivial");
    }

    #[test]
    fn density_gift_msg_is_capped_apply() {
        let SensoryMsg::ShadowInfluence {
            command,
            max_abs,
            duration_ticks,
            features,
            ..
        } = density_gift_msg("density-gift", "live")
        else {
            panic!("density_gift_msg must build a ShadowInfluence");
        };
        assert_eq!(command, "apply");
        assert_eq!(max_abs, Some(0.025));
        assert_eq!(duration_ticks, Some(24));
        assert!(features.iter().all(|v| v.abs() <= 0.025 + 1e-6));
    }
}
