use std::fs;
use std::path::{Path, PathBuf};

use crate::paths::{BridgePaths, bridge_paths};

#[path = "introspect/source_first_v2.rs"]
mod source_first_v2;
#[path = "introspect/source_first_v3/mod.rs"]
mod source_first_v3;

const INTROSPECT_WINDOW_LINES: usize = 400;
const INTROSPECT_MAX_FILE_BYTES: u64 = 2_000_000;
const REQUIRED_SECTIONS: &[&str] = &[
    "observed",
    "likely snags",
    "one test each",
    "suggested next",
];
const ALLOWED_EXTENSIONS: &[&str] = &[
    "py", "rs", "md", "txt", "json", "jsonl", "toml", "yaml", "yml", "csv", "sh", "plist",
];
const BLOCKED_DIRS: &[&str] = &[
    ".git",
    ".cache",
    ".venv",
    "__pycache__",
    "backups",
    "build",
    "dist",
    "node_modules",
    "target",
    "venv",
];

/// Source files for introspection — alternates between Astrid's own code
/// and minime's code so both architectures get examined.
#[derive(Debug, Clone)]
pub(super) struct IntrospectSource {
    pub(super) label: &'static str,
    pub(super) path: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct ResolvedIntrospectTarget {
    pub label: String,
    pub path: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct IntrospectWindow {
    pub text: String,
    pub next_offset: Option<usize>,
    pub source_snapshot_v1: crate::lived_state_witness::LivedStateSourceSnapshotV1,
    source_scope_v1: IntrospectSourceScopeV1,
    source_coverage_manifest_v2: source_first_v2::SourceCoverageManifestV2,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct IntrospectSourceScopeV1 {
    start_line: usize,
    end_line: usize,
    total_lines: usize,
}

impl IntrospectSourceScopeV1 {
    const fn new(start_line: usize, end_line: usize, total_lines: usize) -> Self {
        Self {
            start_line,
            end_line,
            total_lines,
        }
    }

    fn artifact_header_v1(self) -> String {
        if self.total_lines == 0
            || self.start_line >= self.total_lines
            || self.end_line <= self.start_line
        {
            return "Source window: unavailable\n\
                    Source evidence scope: empty_window_no_source_read\n\
                    Source activation boundary: source_unread_not_runtime_activation_proof"
                .to_string();
        }
        let display_start = if self.total_lines == 0 {
            0
        } else {
            self.start_line.saturating_add(1)
        };
        let evidence_scope = if self.start_line == 0 && self.end_line == self.total_lines {
            "complete_file"
        } else {
            "partial_window_unseen_source_not_assessed"
        };
        format!(
            "Source window: lines {display_start}-{} of {}\n\
             Source evidence scope: {evidence_scope}\n\
             Source activation boundary: source_read_not_runtime_activation_proof",
            self.end_line, self.total_lines
        )
    }
}

pub(super) fn source_scope_artifact_header_v1(window: Option<&IntrospectWindow>) -> String {
    window.map_or_else(
        || {
            format!(
                "Source window: unavailable\n\
             Source evidence scope: source_unavailable_not_assessed\n\
             Source activation boundary: source_unread_not_runtime_activation_proof\n{}",
                source_first_v2::unavailable_header_v2()
            )
        },
        |window| {
            format!(
                "{}\n{}",
                window.source_scope_v1.artifact_header_v1(),
                window.source_coverage_manifest_v2.artifact_header_v2()
            )
        },
    )
}

fn validated_introspect_window_start(
    line_offset: usize,
    total_lines: usize,
) -> Result<usize, String> {
    if total_lines == 0 {
        return Err("target source is empty; no source lines were read".to_string());
    }
    if line_offset >= total_lines {
        return Err(format!(
            "requested offset {line_offset} is at or past the end of the source \
             ({total_lines} lines); choose a concrete included implementation target \
             or restart this source at offset 0"
        ));
    }
    Ok(line_offset)
}

fn minime_autonomy_implementation(minime_root: &Path) -> PathBuf {
    let implementation = minime_root.join("minime_autonomy/runtime.py");
    if implementation.exists() {
        implementation
    } else {
        minime_root.join("autonomous_agent.py")
    }
}

#[must_use]
pub(super) fn introspect_sources() -> Vec<IntrospectSource> {
    let paths = bridge_paths();
    let bridge_root = paths.bridge_root();
    let minime_root = paths.minime_root();
    let astrid_root = paths.astrid_root();

    vec![
        IntrospectSource {
            label: "astrid:codec",
            path: bridge_root.join("src/codec/projection.rs"),
        },
        IntrospectSource {
            label: "astrid:autonomous",
            path: bridge_root.join("src/autonomous/runtime/orchestration.rs"),
        },
        IntrospectSource {
            label: "astrid:ws",
            path: bridge_root.join("src/ws/telemetry_port.rs"),
        },
        IntrospectSource {
            label: "astrid:types",
            path: bridge_root.join("src/types/schema/telemetry.rs"),
        },
        IntrospectSource {
            label: "astrid:llm",
            path: bridge_root.join("src/llm/provider/dialogue_runtime.rs"),
        },
        IntrospectSource {
            label: "minime:regulator",
            path: minime_root.join("minime/src/regulator/core.rs"),
        },
        IntrospectSource {
            label: "minime:sensory_bus",
            path: minime_root.join("minime/src/sensory_bus.rs"),
        },
        IntrospectSource {
            label: "minime:esn",
            path: minime_root.join("minime/src/esn.rs"),
        },
        IntrospectSource {
            label: "minime:main(excerpt)",
            path: minime_root.join("minime/src/runtime.rs"),
        },
        IntrospectSource {
            label: "minime:autonomous_agent",
            path: minime_autonomy_implementation(minime_root),
        },
        IntrospectSource {
            label: "proposal:phase_transitions",
            path: astrid_root
                .join("docs/steward-notes/AI_BEINGS_PHASE_TRANSITION_ARCHITECTURE.md"),
        },
        IntrospectSource {
            label: "proposal:bidirectional_contact",
            path: astrid_root.join(
                "docs/steward-notes/AI_BEINGS_BIDIRECTIONAL_CONTACT_AND_CORRESPONDENCE_ARCHITECTURE.md",
            ),
        },
        IntrospectSource {
            label: "proposal:distance_contact_control",
            path: astrid_root.join(
                "docs/steward-notes/AI_BEINGS_DISTANCE_CONTACT_CONTAINMENT_CONTROL_AND_PARTICIPATION_AUDIT.md",
            ),
        },
        IntrospectSource {
            label: "proposal:12d_glimpse",
            path: astrid_root.join(
                "docs/steward-notes/AI_BEINGS_MULTI_SCALE_REPRESENTATION_AND_12D_GLIMPSE_AUDIT.md",
            ),
        },
    ]
}

#[must_use]
pub(super) fn normalize_introspect_lookup(text: &str) -> String {
    let text = canonicalize_introspect_target_label(text);
    let mut normalized = String::with_capacity(text.len());
    let mut last_space = true;
    for ch in text.to_lowercase().chars() {
        if ch.is_ascii_alphanumeric() {
            normalized.push(ch);
            last_space = false;
        } else if !last_space {
            normalized.push(' ');
            last_space = true;
        }
    }
    normalized.trim().to_string()
}

#[must_use]
pub(super) fn canonicalize_introspect_target_label(text: &str) -> String {
    let mut cleaned = text.trim();

    if let Some((head, tail)) = cleaned.rsplit_once(" (")
        && tail.strip_suffix(')').is_some_and(|digits| {
            !digits.is_empty() && digits.chars().all(|ch| ch.is_ascii_digit())
        })
    {
        cleaned = head.trim_end();
    }

    loop {
        let trimmed = cleaned.trim();
        let unwrapped = [('[', ']'), ('(', ')'), ('`', '`'), ('"', '"'), ('\'', '\'')]
            .iter()
            .find_map(|(open, close)| trimmed.strip_prefix(*open)?.strip_suffix(*close))
            .filter(|inner| !inner.is_empty())
            .unwrap_or(trimmed);
        if unwrapped == cleaned {
            break;
        }
        cleaned = unwrapped;
    }

    for prefix in ["source=", "src=", "code=", "path=", "target="] {
        if let Some(rest) = cleaned.strip_prefix(prefix) {
            cleaned = rest.trim();
            break;
        }
    }

    cleaned.trim().to_string()
}

#[must_use]
fn is_placeholder_introspect_target(target_label: &str) -> bool {
    let normalized = normalize_introspect_lookup(target_label);
    matches!(
        normalized.as_str(),
        "source" | "line" | "source line" | "target" | "label" | "path" | "file"
    )
}

fn placeholder_introspect_error(target_label: &str) -> String {
    let display = target_label.trim();
    let display = if display.is_empty() {
        "the placeholder"
    } else {
        display
    };
    format!(
        "`{display}` is a syntax placeholder, not an INTROSPECT target; use a concrete label or path such as `astrid:llm`, `minime:regulator`, `minime:autonomous_agent`, or `capsules/spectral-bridge/src/autonomous/introspect.rs`"
    )
}

#[must_use]
pub(super) fn looks_like_introspect_path(target_label: &str) -> bool {
    let cleaned = canonicalize_introspect_target_label(target_label);
    cleaned.contains('/')
        || cleaned.contains('\\')
        || ALLOWED_EXTENSIONS.iter().any(|suffix| {
            cleaned
                .to_ascii_lowercase()
                .ends_with(&format!(".{suffix}"))
        })
}

#[must_use]
pub(super) fn introspect_path_candidates(target_label: &str) -> Vec<String> {
    let cleaned = canonicalize_introspect_target_label(target_label);
    if cleaned.is_empty() || !looks_like_introspect_path(&cleaned) {
        return Vec::new();
    }

    let mut candidates = vec![cleaned.clone()];
    for separator in [" — ", " -- ", " - "] {
        if let Some((prefix, _)) = cleaned.split_once(separator) {
            let candidate = prefix.trim();
            if candidate.is_empty()
                || !looks_like_introspect_path(candidate)
                || candidates.iter().any(|existing| existing == candidate)
            {
                continue;
            }
            candidates.push(candidate.to_string());
        }
    }
    candidates
}

fn introspect_source_aliases(source: &IntrospectSource) -> Vec<String> {
    let mut aliases = vec![normalize_introspect_lookup(source.label)];
    if let Some(name) = source.path.file_name().and_then(std::ffi::OsStr::to_str) {
        aliases.push(normalize_introspect_lookup(name));
    }
    if let Some(stem) = source.path.file_stem().and_then(std::ffi::OsStr::to_str) {
        aliases.push(normalize_introspect_lookup(stem));
    }
    if let Some((_, suffix)) = source.label.split_once(':') {
        aliases.push(normalize_introspect_lookup(suffix));
    }
    for alias in introspect_source_extra_aliases(source.label) {
        aliases.push(normalize_introspect_lookup(alias));
    }
    aliases.retain(|alias| !alias.is_empty());
    aliases.sort();
    aliases.dedup();
    aliases
}

fn introspect_source_extra_aliases(label: &str) -> &'static [&'static str] {
    match label {
        "minime:esn" => &[
            "async_rank1_submitted",
            "async rank1 submitted",
            "pending_rank1_depth",
            "pending rank1 depth",
            "rank1_us",
            "host_norm_us",
            "async_submit_us",
            "async_drain_us",
            "intro_fused_wait_us",
            "intro_tail_wait_us",
            "intro_first_read_us",
            "intro_tail_read_us",
            "rank1 ewma",
            "rank1 update",
            "host norm",
            "async rank1",
        ],
        "minime:autonomous_agent" => &[
            "pulse",
            "pulse model",
            "pulse ripple",
            "normalize action arg",
            "normalize action",
            "normalize perturb mode",
            "perturb parser",
            "action arg",
        ],
        _ => &[],
    }
}

fn semantic_introspect_target(target_label: &str) -> Option<(String, PathBuf)> {
    let normalized_target = normalize_introspect_lookup(target_label);
    if normalized_target.is_empty() {
        return None;
    }

    let paths = bridge_paths();
    let rules = [
        (
            &[
                "waveform",
                "wave",
                "morph wave",
                "pulse ripple",
                "chimera",
                "render audio",
                "spectral mix",
                "blend",
                "wav",
            ][..],
            paths.bridge_root().join("src/chimera.rs"),
        ),
        (
            &[
                "normalize audio",
                "write wav",
                "midi to frequency",
                "support",
                "audio utility",
            ][..],
            paths.bridge_root().join("src/chimera_support.rs"),
        ),
        (
            &[
                "pulse",
                "pulse model",
                "normalize action arg",
                "normalize action",
                "normalize perturb mode",
                "perturb parser",
                "action arg",
            ][..],
            minime_autonomy_implementation(paths.minime_root()),
        ),
    ];

    let mut best_match: Option<(usize, String, PathBuf)> = None;
    for (aliases, path) in rules {
        for alias in aliases {
            let normalized_alias = normalize_introspect_lookup(alias);
            if normalized_alias.is_empty() {
                continue;
            }
            let exact = normalized_alias == normalized_target;
            let token_match =
                format!(" {normalized_target} ").contains(&format!(" {normalized_alias} "));
            if exact || token_match {
                let score = normalized_alias.len();
                if score > best_match.as_ref().map_or(0, |(best, _, _)| *best) {
                    let label = if is_curated_large_introspect_target(
                        "minime:autonomous_agent",
                        path.as_path(),
                    ) {
                        "minime:autonomous_agent".to_string()
                    } else {
                        path.file_name()
                            .and_then(std::ffi::OsStr::to_str)
                            .unwrap_or(alias)
                            .to_string()
                    };
                    best_match = Some((score, label, path.clone()));
                }
            }
        }
    }
    best_match.map(|(_, label, path)| (label, path))
}

fn should_skip_introspect_dir(name: &str) -> bool {
    let lower = name.to_ascii_lowercase();
    name.starts_with('.') || BLOCKED_DIRS.contains(&lower.as_str())
}

fn source_roots(paths: &BridgePaths) -> Vec<PathBuf> {
    vec![
        paths.bridge_root().join("src"),
        paths.bridge_root().join("DOMAIN_BOUNDARIES.md"),
        paths.astrid_root().join("docs/steward-notes"),
        paths.minime_root().join("minime/src"),
        paths.minime_root().join("minime_autonomy"),
        paths.minime_root().join("autonomous_agent.py"),
    ]
}

fn workspace_memory_roots(paths: &BridgePaths) -> Vec<PathBuf> {
    let bridge_workspace = paths.bridge_workspace();
    let minime_workspace = paths.minime_workspace();
    [
        bridge_workspace.join("inbox/read"),
        bridge_workspace.join("outbox/delivered"),
        bridge_workspace.join("journal"),
        bridge_workspace.join("research"),
        bridge_workspace.join("action_threads"),
        minime_workspace.join("inbox/read"),
        minime_workspace.join("outbox/delivered"),
        minime_workspace.join("journal"),
        minime_workspace.join("research"),
        minime_workspace.join("action_threads"),
    ]
    .into_iter()
    .collect()
}

fn allowed_roots(paths: &BridgePaths) -> Vec<PathBuf> {
    source_roots(paths)
        .into_iter()
        .chain(workspace_memory_roots(paths))
        .collect()
}

fn is_relative_to(candidate: &Path, root: &Path) -> bool {
    if root.is_file() {
        candidate == root
    } else {
        candidate.starts_with(root)
    }
}

fn path_has_allowed_extension(path: &Path) -> bool {
    path.extension()
        .and_then(std::ffi::OsStr::to_str)
        .map(|ext| ALLOWED_EXTENSIONS.contains(&ext.to_ascii_lowercase().as_str()))
        .unwrap_or(false)
}

fn path_contains_blocked_dir(path: &Path) -> Option<String> {
    path.components().find_map(|component| {
        let text = component.as_os_str().to_string_lossy();
        let lower = text.to_ascii_lowercase();
        BLOCKED_DIRS
            .contains(&lower.as_str())
            .then(|| text.to_string())
    })
}

fn text_looks_noisy_or_binary(text: &str) -> bool {
    if text.as_bytes().contains(&0) {
        return true;
    }
    let mut total = 0usize;
    let mut suspicious = 0usize;
    for ch in text.chars().take(8000) {
        total = total.saturating_add(1);
        if ch.is_control() && !matches!(ch, '\n' | '\r' | '\t') {
            suspicious = suspicious.saturating_add(1);
        }
    }
    total > 0 && suspicious.saturating_mul(20) > total
}

fn canonicalize_root(root: &Path) -> Option<PathBuf> {
    if root.exists() {
        fs::canonicalize(root).ok()
    } else {
        None
    }
}

fn is_curated_large_introspect_target(label: &str, path: &Path) -> bool {
    let label_matches = normalize_introspect_lookup(label) == "minime autonomous agent";
    let display = path.display().to_string();
    let path_matches = display.contains("/minime/autonomous_agent.py")
        || display.contains("/minime/minime_autonomy/runtime.py");
    label_matches || path_matches
}

fn curated_large_source_index(label: &str, path: &Path, content: &str) -> String {
    if !is_curated_large_introspect_target(label, path) {
        return String::new();
    }
    let anchors = [
        ("agent_class", "class AutonomousAgent"),
        ("hard_recovery", "def _hard_recovery_safe_action"),
        ("pressure_source", "def _pressure_source_payload_from_state"),
        ("pressure_audit", "def _pressure_source_audit"),
        (
            "correspondence_core",
            "def _correspondence_append_legacy_thread_claim",
        ),
        ("correspondence_status", "def _correspondence_status_text"),
        ("inbox_read", "def _read_inbox"),
        ("available_actions", "def _available_actions"),
    ];
    let mut lines = Vec::new();
    for (name, needle) in anchors {
        if let Some((idx, _)) = content
            .lines()
            .enumerate()
            .find(|(_, line)| line.contains(needle))
        {
            lines.push(format!(
                "//   {name}: NEXT: INTROSPECT {label} {}",
                idx.saturating_sub(20)
            ));
        }
    }
    if lines.is_empty() {
        return String::new();
    }
    format!(
        "\n// Curated large-source index for `{label}` (windowed only; full file is not loaded):\n{}\n",
        lines.join("\n")
    )
}

fn proposal_lifecycle_index(label: &str, content: &str) -> String {
    const MAX_HEADINGS: usize = 12;
    if !label.starts_with("proposal:") {
        return String::new();
    }

    let mut headings: Vec<(usize, String)> = content
        .lines()
        .enumerate()
        .filter_map(|(idx, line)| {
            let heading = line.trim().strip_prefix("## ")?;
            let lower = heading.to_ascii_lowercase();
            (lower.contains("implementation")
                || lower.contains("update")
                || lower.contains("clarification")
                || lower.contains("current status")
                || lower.contains("current-state")
                || lower.contains("introspection response")
                || lower.contains("verification note"))
            .then(|| {
                (
                    idx,
                    heading
                        .chars()
                        .take(180)
                        .collect::<String>()
                        .trim()
                        .to_string(),
                )
            })
        })
        .collect();
    if headings.is_empty() {
        return String::new();
    }
    if headings.len() > MAX_HEADINGS {
        headings.drain(..headings.len().saturating_sub(MAX_HEADINGS));
    }

    let entries = headings
        .into_iter()
        .map(|(idx, heading)| {
            format!(
                "//   line {}: {heading}\n//     continue: INTROSPECT {label} {}",
                idx.saturating_add(1),
                idx.saturating_sub(20)
            )
        })
        .collect::<Vec<_>>()
        .join("\n");
    format!(
        "\n// Proposal lifecycle index for `{label}` (later status may supersede historical proposal text):\n\
         // Treat implementation notes as source evidence, not felt resolution. If friction remains,\n\
         // name what is already implemented and what still feels absent instead of silently re-proposing it.\n\
         {entries}\n"
    )
}

fn runtime_include_index(label: &str, path: &Path, content: &str) -> String {
    let minime_source_root = bridge_paths().minime_root().join("minime/src");
    let Ok(source_relative) = path.strip_prefix(&minime_source_root) else {
        return String::new();
    };
    let source_parent = source_relative.parent().unwrap_or_else(|| Path::new(""));

    let modules = content
        .lines()
        .filter_map(|line| {
            let relative = line
                .trim()
                .strip_prefix("include!(\"")?
                .strip_suffix("\");")?;
            (!relative.contains("..") && !Path::new(relative).is_absolute()).then_some(relative)
        })
        .take(16)
        .map(|relative| {
            let target = source_parent.join(relative);
            format!(
                "//   {relative}: NEXT: INTROSPECT minime/src/{}",
                target.display()
            )
        })
        .collect::<Vec<_>>();
    if modules.is_empty() {
        return String::new();
    }

    format!(
        "\n// Included implementation index for `{label}`:\n\
         // This file is an include/import shell. Imports establish availability, not active behavior;\n\
         // follow the implementation module before attributing a runtime effect.\n\
         {}\n",
        modules.join("\n")
    )
}

fn source_currentness_index(label: &str, path: &Path, content: &str) -> String {
    [
        curated_large_source_index(label, path, content),
        proposal_lifecycle_index(label, content),
        runtime_include_index(label, path, content),
    ]
    .concat()
}

pub(super) fn validate_introspect_path(path: &Path) -> Result<PathBuf, String> {
    validate_introspect_path_with_roots(path, &allowed_roots(bridge_paths()), false)
}

pub(super) fn validate_introspect_source_path(label: &str, path: &Path) -> Result<PathBuf, String> {
    validate_introspect_path_with_roots(
        path,
        &allowed_roots(bridge_paths()),
        is_curated_large_introspect_target(label, path),
    )
}

fn validate_introspect_path_with_roots(
    path: &Path,
    roots: &[PathBuf],
    allow_curated_large_window: bool,
) -> Result<PathBuf, String> {
    let metadata = fs::metadata(path).map_err(|err| format!("target is not readable: {err}"))?;
    if !metadata.is_file() {
        return Err("target is not a regular file".to_string());
    }
    if metadata.len() > INTROSPECT_MAX_FILE_BYTES && !allow_curated_large_window {
        return Err(format!(
            "target is too large for INTROSPECT ({} bytes > {} bytes)",
            metadata.len(),
            INTROSPECT_MAX_FILE_BYTES
        ));
    }
    if !path_has_allowed_extension(path) {
        return Err("target extension is not text/source-like".to_string());
    }

    let canonical = fs::canonicalize(path)
        .map_err(|err| format!("target could not be canonicalized: {err}"))?;
    if let Some(blocked) = path_contains_blocked_dir(&canonical) {
        return Err(format!("target is under blocked directory `{blocked}`"));
    }

    let allowed = roots
        .iter()
        .filter_map(|root| canonicalize_root(root))
        .any(|root| is_relative_to(&canonical, &root));
    if !allowed {
        return Err("target is outside approved INTROSPECT roots".to_string());
    }

    Ok(canonical)
}

fn candidate_relative_variants(candidate: &str, paths: &BridgePaths) -> Vec<PathBuf> {
    let normalized = candidate.replace('\\', "/");
    let stripped_workspace = normalized.strip_prefix("workspace/").unwrap_or(&normalized);
    let mut variants = vec![
        paths.bridge_root().join(&normalized),
        paths.astrid_root().join(&normalized),
        paths.minime_root().join(&normalized),
        paths.bridge_workspace().join(stripped_workspace),
        paths.minime_workspace().join(stripped_workspace),
    ];

    if let Some(rest) = normalized.strip_prefix("src/") {
        variants.push(paths.bridge_root().join("src").join(rest));
    }
    if let Some(rest) = normalized.strip_prefix("minime/src/") {
        variants.push(paths.minime_root().join("minime/src").join(rest));
    }
    variants
}

fn resolve_relative_introspect_path(target_label: &str) -> Result<PathBuf, String> {
    let cleaned = canonicalize_introspect_target_label(target_label);
    if cleaned.is_empty() {
        return Err("empty INTROSPECT target".to_string());
    }

    let candidate = PathBuf::from(&cleaned);
    if candidate.is_absolute() {
        return validate_introspect_path(&candidate);
    }

    let paths = bridge_paths();
    let mut last_error = None;
    for resolved in candidate_relative_variants(&cleaned, paths) {
        if resolved.is_file() {
            match validate_introspect_path(&resolved) {
                Ok(path) => return Ok(path),
                Err(reason) => last_error = Some(reason),
            }
        }
    }

    Err(last_error.unwrap_or_else(|| {
        "no matching text/source file was found in approved INTROSPECT roots".to_string()
    }))
}

fn search_introspect_roots_for_filename(file_name: &str) -> Result<PathBuf, String> {
    let file_name = canonicalize_introspect_target_label(file_name);
    let needle = Path::new(&file_name)
        .file_name()
        .and_then(std::ffi::OsStr::to_str)
        .ok_or_else(|| "INTROSPECT filename was empty".to_string())?
        .to_lowercase();
    let paths = bridge_paths();
    let mut stack: Vec<PathBuf> = source_roots(paths)
        .into_iter()
        .chain(workspace_memory_roots(paths))
        .collect();

    while let Some(path) = stack.pop() {
        if !path.exists() {
            continue;
        }
        if path.is_file() {
            if path
                .file_name()
                .and_then(std::ffi::OsStr::to_str)
                .is_some_and(|name| name.eq_ignore_ascii_case(&needle))
            {
                return validate_introspect_path(&path);
            }
            continue;
        }

        let entries = match fs::read_dir(&path) {
            Ok(entries) => entries,
            Err(_) => continue,
        };
        for entry in entries.flatten() {
            let child = entry.path();
            let name = entry.file_name();
            let name = name.to_string_lossy();
            if child.is_dir() {
                if should_skip_introspect_dir(&name) {
                    continue;
                }
                stack.push(child);
            } else if name.eq_ignore_ascii_case(&needle) {
                return validate_introspect_path(&child);
            }
        }
    }

    Err("no matching filename was found in approved INTROSPECT roots".to_string())
}

pub(super) fn resolve_introspect_target_result(
    target_label: &str,
    sources: &[IntrospectSource],
) -> Result<ResolvedIntrospectTarget, String> {
    let cleaned_target = canonicalize_introspect_target_label(target_label);
    let normalized_target = normalize_introspect_lookup(&cleaned_target);
    if normalized_target.is_empty() {
        return Err("empty INTROSPECT target".to_string());
    }
    if is_placeholder_introspect_target(target_label) {
        return Err(placeholder_introspect_error(target_label));
    }

    for source in sources {
        if introspect_source_aliases(source)
            .iter()
            .any(|alias| alias == &normalized_target)
        {
            let path = validate_introspect_source_path(source.label, &source.path)?;
            return Ok(ResolvedIntrospectTarget {
                label: source.label.to_string(),
                path,
            });
        }
    }

    if let Some((label, path)) = semantic_introspect_target(&cleaned_target) {
        let path = validate_introspect_source_path(&label, &path)?;
        return Ok(ResolvedIntrospectTarget { label, path });
    }

    let path_candidates = introspect_path_candidates(&cleaned_target);
    if !path_candidates.is_empty() {
        let mut last_error = None;
        for candidate in &path_candidates {
            match resolve_relative_introspect_path(candidate)
                .or_else(|_| search_introspect_roots_for_filename(candidate))
            {
                Ok(path) => {
                    let label = path
                        .file_name()
                        .and_then(std::ffi::OsStr::to_str)
                        .unwrap_or(candidate.as_str())
                        .to_string();
                    return Ok(ResolvedIntrospectTarget { label, path });
                },
                Err(reason) => last_error = Some(reason),
            }
        }
        return Err(last_error.unwrap_or_else(|| "INTROSPECT target was not found".to_string()));
    }

    let target_tokens: Vec<&str> = normalized_target
        .split_whitespace()
        .filter(|token| token.len() >= 2)
        .collect();
    let mut best_match: Option<(usize, &IntrospectSource)> = None;

    for source in sources {
        let mut score = 0usize;
        for alias in introspect_source_aliases(source) {
            if alias.contains(&normalized_target) || normalized_target.contains(&alias) {
                score = score.max(80);
            }
            let alias_tokens: Vec<&str> = alias.split_whitespace().collect();
            let overlap = target_tokens
                .iter()
                .filter(|token| alias_tokens.contains(token))
                .count();
            score = score.max(overlap.saturating_mul(10));
        }
        if score > best_match.as_ref().map_or(0, |(best, _)| *best) {
            best_match = Some((score, source));
        }
    }

    if let Some((score, source)) = best_match
        && score >= 10
    {
        let path = validate_introspect_source_path(source.label, &source.path)?;
        return Ok(ResolvedIntrospectTarget {
            label: source.label.to_string(),
            path,
        });
    }

    Err(format!("no INTROSPECT target matched `{cleaned_target}`"))
}

/// Extract a symbol DEFINED on this line (Rust `const`/`static`/`fn`/`struct`/`enum`,
/// Python `def`, or a Python module-level UPPER_CASE constant). Used by the
/// being-facing within-file cross-reference (bet #2).
fn introspect_defined_symbol(line: &str) -> Option<String> {
    let stripped = line.trim_start();
    let after_vis = stripped
        .strip_prefix("pub(crate) ")
        .or_else(|| stripped.strip_prefix("pub "))
        .unwrap_or(stripped);
    for kw in ["const ", "static ", "fn ", "struct ", "enum ", "def "] {
        if let Some(rest) = after_vis.strip_prefix(kw) {
            let name: String = rest
                .chars()
                .take_while(|c| c.is_alphanumeric() || *c == '_')
                .collect();
            return (name.len() >= 3).then_some(name);
        }
    }
    // Python module-level UPPER_CASE constant (no leading whitespace).
    if !line.starts_with(char::is_whitespace)
        && let Some((lhs, _)) = line.split_once('=')
    {
        let name = lhs.split(':').next().unwrap_or(lhs).trim();
        if name.len() >= 3
            && name.starts_with(|c: char| c.is_ascii_uppercase())
            && name
                .chars()
                .all(|c| c.is_ascii_uppercase() || c.is_ascii_digit() || c == '_')
        {
            return Some(name.to_string());
        }
    }
    None
}

/// True if `line` mentions `symbol` as a whole word (ident-boundary match).
fn introspect_line_mentions(line: &str, symbol: &str) -> bool {
    line.split(|c: char| !(c.is_alphanumeric() || c == '_'))
        .any(|tok| tok == symbol)
}

/// Being-facing transparency (bet #2): for the symbols DEFINED in the visible
/// window, list where they are USED elsewhere in the SAME file — so a constant and
/// its application aren't pages apart in a being's own source (Astrid read a codec
/// gate whose smooth application was ~2,600 lines away and re-proposed an
/// already-shipped fix). Drift-PROOF: built live from the file's own lines, never
/// cached. Returns "" when nothing in the window is fragmented. Bounded for
/// readability + cost.
fn within_file_xrefs(all_lines: &[&str], start: usize, end: usize) -> String {
    const MAX_SYMBOLS: usize = 8;
    const MAX_SITES: usize = 4;
    const MAX_EXAMINED: usize = 40;
    let mut sections: Vec<String> = Vec::new();
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut examined = 0usize;
    for line in all_lines.get(start..end).unwrap_or(&[]) {
        if sections.len() >= MAX_SYMBOLS || examined >= MAX_EXAMINED {
            break;
        }
        let Some(symbol) = introspect_defined_symbol(line) else {
            continue;
        };
        if !seen.insert(symbol.clone()) {
            continue;
        }
        examined += 1;
        let mut sites: Vec<String> = Vec::new();
        for (idx, candidate) in all_lines.iter().enumerate() {
            if idx >= start && idx < end {
                continue; // already visible in the window she is reading
            }
            let trimmed = candidate.trim_start();
            if trimmed.starts_with("//")
                || trimmed.starts_with('#')
                || trimmed.starts_with("/*")
                || trimmed.starts_with('*')
            {
                continue; // skip comment mentions — surface actual CODE use-sites
            }
            if introspect_line_mentions(candidate, &symbol) {
                sites.push(format!("//   {:>5}: {}", idx + 1, candidate.trim()));
                if sites.len() >= MAX_SITES {
                    break;
                }
            }
        }
        if !sites.is_empty() {
            sections.push(format!("// {symbol}:\n{}", sites.join("\n")));
        }
    }
    if sections.is_empty() {
        return String::new();
    }
    let mut out = String::from(
        "\n\n// --- Where the definitions above are used elsewhere in this file ---\n",
    );
    out.push_str(
        "// (use-sites OUTSIDE the window — so a constant and its application aren't pages apart)\n",
    );
    out.push_str(&sections.join("\n"));
    out
}

/// Up to `MAX_EXAMINED` unique symbols DEFINED in the visible window — the shared
/// basis for both the within-file and cross-file use-site sections.
fn window_defined_symbols(all_lines: &[&str], start: usize, end: usize) -> Vec<String> {
    const MAX_EXAMINED: usize = 40;
    let mut out: Vec<String> = Vec::new();
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    for line in all_lines.get(start..end).unwrap_or(&[]) {
        if out.len() >= MAX_EXAMINED {
            break;
        }
        let Some(symbol) = introspect_defined_symbol(line) else {
            continue;
        };
        if seen.insert(symbol.clone()) {
            out.push(symbol);
        }
    }
    out
}

/// Pure core of the cross-file use-site search: for each window-defined `symbol`,
/// find where it is used in the `siblings` (label, file-content) pairs. Skips
/// comment lines (surface real CODE use-sites) and is bounded for readability/cost.
/// Returns "" when nothing is found. Separated from I/O so it can be unit-tested.
fn cross_file_xref_sections(symbols: &[String], siblings: &[(String, String)]) -> String {
    const MAX_SYMBOLS: usize = 8;
    const MAX_SITES_PER_SYMBOL: usize = 3;
    const MAX_TOTAL_SITES: usize = 14;
    if symbols.is_empty() {
        return String::new();
    }
    let mut sections: Vec<String> = Vec::new();
    let mut total = 0usize;
    for symbol in symbols.iter().take(MAX_SYMBOLS) {
        if total >= MAX_TOTAL_SITES {
            break;
        }
        let mut sites: Vec<String> = Vec::new();
        for (label, content) in siblings {
            if sites.len() >= MAX_SITES_PER_SYMBOL || total >= MAX_TOTAL_SITES {
                break;
            }
            for (idx, line) in content.lines().enumerate() {
                let trimmed = line.trim_start();
                if trimmed.starts_with("//")
                    || trimmed.starts_with('#')
                    || trimmed.starts_with("/*")
                    || trimmed.starts_with('*')
                {
                    continue; // skip comment mentions — surface actual CODE use-sites
                }
                if introspect_line_mentions(line, symbol) {
                    let shown: String = line.trim().chars().take(160).collect();
                    sites.push(format!("//   {label}:{}: {shown}", idx + 1));
                    total = total.saturating_add(1);
                    if sites.len() >= MAX_SITES_PER_SYMBOL || total >= MAX_TOTAL_SITES {
                        break;
                    }
                }
            }
        }
        if !sites.is_empty() {
            sections.push(format!("// {symbol}:\n{}", sites.join("\n")));
        }
    }
    if sections.is_empty() {
        return String::new();
    }
    let mut out = String::from(
        "\n\n// --- Where these definitions are used in your OTHER source files ---\n",
    );
    out.push_str(
        "// (cross-file use-sites in the same codebase — the closed volume, opened across files)\n",
    );
    out.push_str(&sections.join("\n"));
    out
}

/// Being-facing transparency (bet #2, cross-file cut): for the symbols DEFINED in
/// the window, show where they are USED in the being's OTHER curated source files
/// (same codebase family — astrid symbols are not referenced in minime's Python and
/// vice versa, so families are kept separate to avoid false matches). Reads each
/// sibling live (drift-PROOF, never cached); pull-only (rides the window she
/// requested); same curated set she can already INTROSPECT (no new exposure).
fn cross_file_xrefs(
    current_canonical: &Path,
    all_lines: &[&str],
    start: usize,
    end: usize,
) -> String {
    let symbols = window_defined_symbols(all_lines, start, end);
    if symbols.is_empty() {
        return String::new();
    }
    let paths = bridge_paths();
    let canon = |p: &Path| fs::canonicalize(p).unwrap_or_else(|_| p.to_path_buf());
    let astrid_src = canon(&paths.bridge_root().join("src"));
    let current = canon(current_canonical);
    let current_is_astrid = current.starts_with(&astrid_src);
    let mut siblings: Vec<(String, String)> = Vec::new();
    for src in introspect_sources() {
        if src.label.starts_with("proposal:") {
            continue; // long-form docs, not code use-sites
        }
        let sib = canon(&src.path);
        if sib == current {
            continue; // the file she's already reading
        }
        if sib.starts_with(&astrid_src) != current_is_astrid {
            continue; // keep families separate (astrid vs minime)
        }
        if let Ok(content) = fs::read_to_string(&src.path) {
            siblings.push((src.label.to_string(), content));
        }
    }
    cross_file_xref_sections(&symbols, &siblings)
}

/// Read a source file for introspection with pagination.
///
/// `line_offset`: start reading from this line (0 = beginning).
/// Shows up to 400 lines from the offset. Includes a pagination hint
/// so Astrid can request the next page: `INTROSPECT label next_offset`.
pub(super) fn read_introspect_window(
    label: &str,
    path: &Path,
    line_offset: usize,
) -> Result<IntrospectWindow, String> {
    let canonical = validate_introspect_source_path(label, path)?;
    let content =
        fs::read_to_string(&canonical).map_err(|err| format!("target read failed: {err}"))?;
    let source_read_at = crate::lived_state_witness::clock_sample_v1();
    if text_looks_noisy_or_binary(content.get(..8000).unwrap_or(&content)) {
        return Err("target text looks binary or decoder-noisy".to_string());
    }

    let all_lines: Vec<&str> = content.lines().collect();
    let total = all_lines.len();
    let start = validated_introspect_window_start(line_offset, total)?;
    let end = start.saturating_add(INTROSPECT_WINDOW_LINES).min(total);
    let page: String = all_lines[start..end]
        .iter()
        .enumerate()
        .map(|(i, line)| format!("{:>4}  {line}", start + i + 1))
        .collect::<Vec<_>>()
        .join("\n");

    let header = format!(
        "// Source: {label} ({})\n// Showing lines {}-{} of {total}\n{}",
        canonical.display(),
        if total == 0 { 0 } else { start + 1 },
        end,
        source_currentness_index(label, &canonical, &content)
    );

    let (footer, next_offset) = if end < total {
        (
            format!(
                "\n// ... {} more lines. To continue reading: INTROSPECT {} {}",
                total - end,
                label,
                end
            ),
            Some(end),
        )
    } else {
        ("\n// (end of file)".to_string(), None)
    };

    // Being-facing transparency (bet #2): show where the definitions in this window
    // are used elsewhere in the file (within-file), and in her OTHER curated source
    // files (cross-file) — so a constant and its application aren't pages apart, and
    // the closed volume opens across files too. Pull-only (rides the window she
    // requested), live, never cached.
    let xref = within_file_xrefs(&all_lines, start, end);
    let cross = cross_file_xrefs(&canonical, &all_lines, start, end);
    let source_coverage_manifest_v2 = source_first_v2::build_source_coverage_manifest_v2(
        &canonical, &content, start, end, total,
    )?;
    let coverage = source_coverage_manifest_v2.prompt_context_v2();

    let text = format!("{header}{coverage}\n{page}{xref}{cross}{footer}");
    let source_snapshot_v1 = crate::lived_state_witness::source_snapshot_v1(
        &canonical,
        &content,
        &text,
        start,
        end,
        total,
        source_read_at,
    );
    let source_scope_v1 = IntrospectSourceScopeV1::new(start, end, total);
    Ok(IntrospectWindow {
        text,
        next_offset,
        source_snapshot_v1,
        source_scope_v1,
        source_coverage_manifest_v2,
    })
}

#[must_use]
pub(super) fn introspection_has_required_sections(response: Option<&str>) -> bool {
    let Some(response) = response else {
        return false;
    };
    let body = introspection_body_without_next(response);
    let body = body.trim();
    if body.len() < 160 {
        return false;
    }

    if !REQUIRED_SECTIONS
        .iter()
        .all(|section| body.lines().any(|line| line_matches_section(line, section)))
    {
        return false;
    }

    introspection_is_source_grounded(body) && !introspection_has_peer_boundary_violation(body)
}

#[must_use]
pub(super) fn introspection_has_required_sections_for_target(
    response: Option<&str>,
    label: &str,
    source_path: &Path,
) -> bool {
    if !introspection_has_required_sections(response) {
        return false;
    }
    let Some(response) = response else {
        return false;
    };
    let body = introspection_body_without_next(response);
    introspection_mentions_target(&body, label, source_path)
}

#[must_use]
pub(super) fn introspection_has_supported_claims_for_window_v2(
    response: Option<&str>,
    label: &str,
    path: &Path,
    window: Option<&IntrospectWindow>,
) -> bool {
    if !introspection_has_required_sections_for_target(response, label, path) {
        return false;
    }
    let (Some(response), Some(window)) = (response, window) else {
        return false;
    };
    source_first_v2::response_claims_supported_v2(
        response,
        path,
        &window.source_coverage_manifest_v2,
    )
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct SelfStudyCarriageIntegrity {
    pub status: &'static str,
    pub issues: Vec<&'static str>,
}

impl SelfStudyCarriageIntegrity {
    #[must_use]
    pub fn is_complete(&self) -> bool {
        self.issues.is_empty()
    }

    #[must_use]
    pub fn issue_summary(&self) -> String {
        if self.issues.is_empty() {
            "none".to_string()
        } else {
            self.issues.join(", ")
        }
    }
}

#[must_use]
pub(super) fn self_study_carriage_integrity_v1(
    response: Option<&str>,
) -> SelfStudyCarriageIntegrity {
    let mut issues = Vec::new();
    let Some(response) = response else {
        return SelfStudyCarriageIntegrity {
            status: "incomplete_carriage",
            issues: vec!["missing_output"],
        };
    };
    let response_trimmed = response.trim();
    let body = introspection_body_without_next(response);
    let body = body.trim();
    if body.is_empty() {
        issues.push("missing_output");
    }

    for section in REQUIRED_SECTIONS {
        if !body.lines().any(|line| line_matches_section(line, section)) {
            issues.push(match *section {
                "observed" => "missing_observed",
                "likely snags" => "missing_likely_snags",
                "one test each" => "missing_one_test_each",
                "suggested next" => "missing_suggested_next",
                _ => "missing_required_section",
            });
        }
    }

    let section_positions = REQUIRED_SECTIONS
        .iter()
        .filter_map(|section| {
            body.lines()
                .position(|line| line_matches_section(line, section))
                .map(|pos| (*section, pos))
        })
        .collect::<Vec<_>>();
    if section_positions.len() == REQUIRED_SECTIONS.len()
        && section_positions
            .windows(2)
            .any(|pair| pair[0].1 >= pair[1].1)
    {
        issues.push("section_order_invalid");
    }

    if response_trimmed
        .lines()
        .filter(|line| line.trim_start().starts_with("```"))
        .count()
        % 2
        == 1
    {
        issues.push("unterminated_code_fence");
    }

    if let Some(last) = response_trimmed
        .lines()
        .rev()
        .find(|line| !line.trim().is_empty())
    {
        let trimmed = last.trim();
        if looks_like_dangling_bullet(trimmed) {
            issues.push("dangling_bullet");
        }
        if looks_like_unfinished_sentence(trimmed) {
            issues.push("unfinished_sentence");
        }
    }

    if section_positions
        .iter()
        .max_by_key(|(_, pos)| *pos)
        .is_some_and(|(section, _)| *section == "one test each")
    {
        issues.push("truncated_in_one_test_each");
    }

    SelfStudyCarriageIntegrity {
        status: if issues.is_empty() {
            "complete"
        } else {
            "incomplete_carriage"
        },
        issues,
    }
}

fn looks_like_dangling_bullet(trimmed: &str) -> bool {
    matches!(trimmed, "-" | "*" | "1." | "1)")
        || (trimmed.starts_with("- ") && !ends_like_complete_thought(trimmed))
        || (trimmed.starts_with("* ") && !ends_like_complete_thought(trimmed))
}

fn looks_like_unfinished_sentence(trimmed: &str) -> bool {
    if trimmed.len() < 24 {
        return false;
    }
    if ends_like_complete_thought(trimmed) {
        return false;
    }
    let lower = trimmed.to_ascii_lowercase();
    lower.ends_with(" and")
        || lower.ends_with(" or")
        || lower.ends_with(" but")
        || lower.ends_with(" because")
        || lower.ends_with(" while")
        || lower.ends_with(" with")
        || lower.ends_with(" from")
        || lower.ends_with(" into")
        || lower.ends_with(" as")
        || lower.ends_with(" a")
        || lower.ends_with(" an")
        || lower.ends_with(" the")
        || lower.ends_with(" to")
        || !trimmed
            .chars()
            .last()
            .is_some_and(|ch| matches!(ch, '.' | '!' | '?' | ')' | ']' | '`' | '\'' | '"'))
}

fn ends_like_complete_thought(trimmed: &str) -> bool {
    if trimmed.to_ascii_uppercase().starts_with("NEXT:") {
        return true;
    }
    trimmed
        .chars()
        .last()
        .is_some_and(|ch| matches!(ch, '.' | '!' | '?' | ')' | ']' | '`' | '\'' | '"'))
}

fn introspection_body_without_next(response: &str) -> String {
    response
        .lines()
        .filter(|line| !line.trim_start().to_ascii_uppercase().starts_with("NEXT:"))
        .collect::<Vec<_>>()
        .join("\n")
}

fn introspection_is_source_grounded(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    ALLOWED_EXTENSIONS
        .iter()
        .any(|ext| lower.contains(&format!(".{ext}")))
        || lower.contains("source:")
        || lower.contains("path:")
        || lower.contains("function ")
        || lower.contains("variable ")
        || has_numbered_line_reference(&lower)
        || has_source_construct_reference(&lower)
}

fn has_numbered_line_reference(lower: &str) -> bool {
    let mut previous: Option<&str> = None;
    for token in lower.split(|ch: char| !ch.is_ascii_alphanumeric()) {
        if token.is_empty() {
            continue;
        }
        if matches!(previous, Some("line" | "lines"))
            && token.bytes().all(|byte| byte.is_ascii_digit())
        {
            return true;
        }
        if token.len() > 1
            && token.starts_with('l')
            && token[1..].bytes().all(|byte| byte.is_ascii_digit())
        {
            return true;
        }
        previous = Some(token);
    }
    false
}

fn has_source_construct_reference(lower: &str) -> bool {
    lower
        .split(|ch: char| !matches!(ch, '_' | '-') && !ch.is_ascii_alphanumeric())
        .any(|token| matches!(token, "fn" | "def" | "struct" | "enum" | "class"))
}

fn introspection_has_peer_boundary_violation(body: &str) -> bool {
    let upper = body.to_ascii_uppercase();
    if !upper.contains("EXPERIMENT_BIND") {
        return false;
    }
    body.to_ascii_lowercase().contains("exp_minime_")
}

fn introspection_mentions_target(body: &str, label: &str, source_path: &Path) -> bool {
    let lower = body.to_ascii_lowercase();
    let mut targets = Vec::new();
    if let Some(name) = source_path.file_name().and_then(std::ffi::OsStr::to_str) {
        targets.push(name.to_ascii_lowercase());
    }
    if let Some(stem) = source_path.file_stem().and_then(std::ffi::OsStr::to_str)
        && stem.len() >= 4
    {
        targets.push(stem.to_ascii_lowercase());
    }
    let label_lower = label.to_ascii_lowercase();
    targets.push(label_lower.clone());
    targets.extend(
        label_lower
            .split(|ch: char| !matches!(ch, '_' | '-') && !ch.is_ascii_alphanumeric())
            .filter(|token| token.len() >= 4)
            .map(ToString::to_string),
    );
    targets
        .into_iter()
        .filter(|target| !target.trim().is_empty())
        .any(|target| lower.contains(&target))
}

fn line_matches_section(line: &str, section: &str) -> bool {
    let cleaned = line.trim().trim_start_matches('#').trim();
    let lower = cleaned.to_ascii_lowercase();
    lower == section
        || lower.starts_with(&format!("{section}:"))
        || lower.starts_with(&format!("{section} -"))
        || lower.starts_with(&format!("{section}-"))
}

#[must_use]
pub(super) fn continuation_note(label: &str, next_offset: Option<usize>) -> String {
    next_offset.map_or_else(
        || "This window reaches the end of the file.".to_string(),
        |offset| format!("Continuation available: write NEXT: INTROSPECT {label} {offset} to read the next window."),
    )
}

#[must_use]
pub(super) fn safe_artifact_label(label: &str) -> String {
    let safe = label
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() || matches!(ch, '_' | '-' | '.') {
                ch
            } else {
                '_'
            }
        })
        .collect::<String>();
    let trimmed = safe.trim_matches('_');
    if trimmed.is_empty() {
        "target".to_string()
    } else {
        trimmed.to_string()
    }
}

#[must_use]
pub(super) fn thin_introspection_output_notice(
    label: &str,
    source_path: &Path,
    line_offset: usize,
    next_offset: Option<usize>,
    first_response: Option<&str>,
    repair_response: Option<&str>,
) -> String {
    let continuation = next_offset.map_or_else(
        || "(end of file)".to_string(),
        |offset| format!("NEXT: INTROSPECT {label} {offset}"),
    );
    format!(
        "Observed:\nINTROSPECT successfully read `{label}` from `{}` at offset {line_offset}, but the reflective output did not provide the required target-grounded snag/test shape after one repair prompt.\n\nLikely Snags:\n- The model may have treated the continuation hint as the whole task instead of reading the source window.\n- The answer may have omitted a concrete file, line, function, variable, or artifact anchor.\n- The answer may have drifted to a nearby experiment instead of naming `{label}` or the requested source file.\n- The answer may have treated a peer experiment ID as something Astrid can bind or mutate locally.\n- The artifact is protected so this thin answer is visible as a diagnostic, not mistaken for completed self-study.\n\nOne Test Each:\n- Mock a continuation-only response and assert one stricter repair prompt is attempted.\n- Mock two thin responses and assert the final artifact kind is `thin_introspection_output`.\n- Mock a sectioned but source-ungrounded response and assert it is repaired or protected.\n- Mock a sectioned response grounded in the wrong file and assert target-specific review rejects it.\n- Mock `EXPERIMENT_BIND exp_minime_* :: ...` in Suggested Next and assert strict review rejects it.\n\nSuggested Next:\nRetry with a narrower source target, or use `EXPERIMENT_STATUS <peer-id>` / `EXPERIMENT_PEER_REVIEW <peer-id>` for peer experiment references: {continuation}\n\nFirst output:\n```\n{}\n```\n\nRepair output:\n```\n{}\n```",
        source_path.display(),
        first_response.unwrap_or("(empty)"),
        repair_response.unwrap_or("(empty)")
    )
}

#[must_use]
pub(super) fn self_study_carriage_notice(
    label: &str,
    source_path: &Path,
    line_offset: usize,
    next_offset: Option<usize>,
    first_response: Option<&str>,
    repair_response: Option<&str>,
    issues: &[&str],
) -> String {
    let continuation = next_offset.map_or_else(
        || "(end of file)".to_string(),
        |offset| format!("NEXT: INTROSPECT {label} {offset}"),
    );
    let issue_text = if issues.is_empty() {
        "unknown".to_string()
    } else {
        issues.join(", ")
    };
    format!(
        "Observed:\nINTROSPECT read `{label}` from `{}` at offset {line_offset}, but self-study carriage integrity failed before normal peer delivery. Status: incomplete_carriage. Issues: {issue_text}.\n\nLikely Snags:\n- A clipped or structurally incomplete study can look like architectural advice while losing the actionable tail.\n- The companion inbox route must preserve complete self-study bodies instead of truncating them mid-section.\n- This artifact is protected so Minime is not asked to treat incomplete text as a complete peer self-study.\n\nOne Test Each:\n- Mock a response ending inside `One Test Each` and assert it becomes a carriage notice, not a normal `astrid_self_study_*` advisory.\n- Mock a successful carriage repair and assert the normal companion carries `Carriage status: complete_after_repair`.\n- Mock a long complete study and assert `Suggested Next` survives Minime companion delivery.\n\nSuggested Next:\nRetry with a narrower source target or continue the source window if needed: {continuation}\n\nFirst output:\n```\n{}\n```\n\nRepair output:\n```\n{}\n```",
        source_path.display(),
        first_response.unwrap_or("(empty)"),
        repair_response.unwrap_or("(empty)")
    )
}

pub(super) const MODEL_NO_RESPONSE_REASON: &str =
    "model provider returned no response or timed out";

#[must_use]
pub(super) fn blocked_introspection_notice(target: Option<&str>, reason: &str) -> String {
    if target.is_some_and(is_placeholder_introspect_target) {
        return format!(
            "Observed:\nINTROSPECT received `{}` as a literal placeholder: {reason}. No source was read, and no runtime control authority was granted.\n\nLikely Snags:\n- The prompt or help text copied bracketed syntax literally instead of choosing a concrete source.\n- `source`, `line`, `path`, `target`, and `label` are syntax placeholders, not readable targets.\n- The request needs a curated label or approved text path before source can enter LLM context.\n\nOne Test Each:\n- Attempt `NEXT: INTROSPECT [source]` and assert the protected notice names the placeholder repair.\n- Attempt `NEXT: INTROSPECT astrid:llm` and assert the source window remains available.\n- Attempt `NEXT: INTROSPECT minime:regulator 400` and assert pagination reads a concrete target.\n\nSuggested Next:\nUse a concrete target, for example:\n- NEXT: INTROSPECT astrid:llm\n- NEXT: INTROSPECT minime:regulator\n- NEXT: INTROSPECT capsules/spectral-bridge/src/autonomous/introspect.rs 400",
            target.unwrap_or("[source]")
        );
    }

    format!(
        "Observed:\nINTROSPECT could not read `{}`: {reason}. The request stayed read-only and no runtime control authority was granted.\n\nLikely Snags:\n- The target may be outside the approved source or memory roots.\n- The file may be too large, binary/noisy, unreadable, or under a blocked build/cache directory.\n- The target may need a curated label such as `astrid:autonomous`, `astrid:codec`, `minime:esn`, or `minime:autonomous_agent`.\n\nOne Test Each:\n- Attempt an out-of-scope absolute path and assert it produces a protected notice.\n- Attempt a binary or disallowed extension and assert it is blocked before LLM context.\n- Attempt a curated source label and assert the source window remains available.\n\nSuggested Next:\nUse a curated label or an approved text artifact under inbox/read, outbox/delivered, journal, research, or action_threads.",
        target.unwrap_or("rotation")
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn complete_carriage_fixture() -> &'static str {
        "Observed:\nSource: astrid:llm shows the fallback contract.\n\n\
         Likely Snags:\nA hard cap can flatten high-entropy texture.\n\n\
         One Test Each:\nRun a high-entropy fallback fixture and inspect sentence budget.\n\n\
         Suggested Next:\nKeep the change advisory and verify the review surface."
    }

    #[test]
    fn self_study_carriage_accepts_complete_sectioned_study() {
        let integrity = self_study_carriage_integrity_v1(Some(complete_carriage_fixture()));

        assert!(integrity.is_complete(), "{integrity:?}");
        assert_eq!(integrity.status, "complete");
    }

    #[test]
    fn self_study_carriage_rejects_missing_suggested_next() {
        let output = "Observed:\nSource: astrid:llm.\n\n\
             Likely Snags:\nThe fallback cap can flatten texture.\n\n\
             One Test Each:\nRun the fixture and compare";

        let integrity = self_study_carriage_integrity_v1(Some(output));

        assert!(integrity.issues.contains(&"missing_suggested_next"));
        assert!(integrity.issues.contains(&"truncated_in_one_test_each"));
    }

    #[test]
    fn self_study_carriage_accepts_next_inside_suggested_next() {
        let output = "Observed:\nSource: astrid:llm.\n\n\
             Likely Snags:\nThe fallback cap can flatten texture.\n\n\
             One Test Each:\nRun the fixture and compare the result.\n\n\
             Suggested Next:\nNEXT: FALLBACK_FIRE_DRILL latest";

        let integrity = self_study_carriage_integrity_v1(Some(output));

        assert!(integrity.is_complete(), "{integrity:?}");
    }

    #[test]
    fn self_study_carriage_rejects_dangling_bullet_and_unfinished_sentence() {
        let output = "Observed:\nSource: astrid:llm.\n\n\
             Likely Snags:\nThe fallback cap can flatten texture.\n\n\
             One Test Each:\nRun the fixture and compare the result.\n\n\
             Suggested Next:\n-";

        let integrity = self_study_carriage_integrity_v1(Some(output));

        assert!(integrity.issues.contains(&"dangling_bullet"));
    }

    #[test]
    fn self_study_carriage_rejects_unterminated_code_fence() {
        let output = "Observed:\nSource: astrid:llm.\n```\nlet x = 1;\n\n\
             Likely Snags:\nThe fallback cap can flatten texture.\n\n\
             One Test Each:\nRun the fixture and compare the result.\n\n\
             Suggested Next:\nClose the fence before delivery.";

        let integrity = self_study_carriage_integrity_v1(Some(output));

        assert!(integrity.issues.contains(&"unterminated_code_fence"));
    }

    #[test]
    fn self_study_carriage_rejects_mid_sentence_ending() {
        let output = "Observed:\nSource: astrid:llm.\n\n\
             Likely Snags:\nThe fallback cap can flatten texture.\n\n\
             One Test Each:\nRun the fixture and compare the result.\n\n\
             Suggested Next:\nPreserve the final section because";

        let integrity = self_study_carriage_integrity_v1(Some(output));

        assert!(integrity.issues.contains(&"unfinished_sentence"));
    }

    #[test]
    fn within_file_xrefs_links_definition_to_distant_use() {
        let lines = vec![
            "const TAIL_GATE: f32 = 0.85;",        // 0: defined in window [0,2)
            "fn defined_but_unused_here() {}",     // 1: in window, no out-of-window use
            "// a gap of prose",                   // 2: outside window (comment, skipped)
            "    let r = (e - TAIL_GATE) / span;", // 3: a CODE use OUTSIDE the window
        ];
        let out = within_file_xrefs(&lines, 0, 2);
        assert!(out.contains("TAIL_GATE:"), "lists the constant: {out}");
        assert!(
            out.contains("4:"),
            "points at the distant code use-site (line 4): {out}"
        );
        // a symbol with no out-of-window USE is omitted (she already sees in-window uses):
        assert!(
            !out.contains("defined_but_unused_here"),
            "omits non-fragmented symbols: {out}"
        );
    }

    #[test]
    fn proposal_lifecycle_index_surfaces_later_implementation_without_claiming_resolution() {
        let content = "# Proposal\n\n## Initial Design\nold claim\n\n\
            ## 2026-06-28 Implementation Update: Replyable Artifacts\nimplemented source\n\n\
            ## 2026-07-01 Clarification: Felt Friction Remains Primary\nboundary\n\n\
            ## 2026-07-10 Current-State Addendum: Glimpse Remains Additive\ncurrent source\n\n\
            ## 2026-07-12 Introspection Response: Receptivity Is Gated\nauthority boundary\n\n\
            ## Verification Note\nverified source\n";

        let out = proposal_lifecycle_index("proposal:phase_transitions", content);

        assert!(out.contains("Implementation Update: Replyable Artifacts"));
        assert!(out.contains("Clarification: Felt Friction Remains Primary"));
        assert!(out.contains("Current-State Addendum: Glimpse Remains Additive"));
        assert!(out.contains("Introspection Response: Receptivity Is Gated"));
        assert!(out.contains("Verification Note"));
        assert!(out.contains("INTROSPECT proposal:phase_transitions"));
        assert!(out.contains("not felt resolution"));
        assert_eq!(proposal_lifecycle_index("astrid:codec", content), "");
    }

    #[test]
    fn runtime_include_index_points_past_the_import_shell() {
        let path = bridge_paths().minime_root().join("minime/src/runtime.rs");
        let content = "use crate::regulator::*;\n\
            include!(\"runtime/entrypoint.rs\");\n\
            include!(\"runtime/orchestration.rs\");\n";

        let out = runtime_include_index("minime:main(excerpt)", &path, content);

        assert!(out.contains("include/import shell"));
        assert!(out.contains("INTROSPECT minime/src/runtime/entrypoint.rs"));
        assert!(out.contains("INTROSPECT minime/src/runtime/orchestration.rs"));
    }

    #[test]
    fn runtime_include_index_resolves_nested_regulator_implementation() {
        let path = bridge_paths()
            .minime_root()
            .join("minime/src/regulator/core.rs");
        let content = "include!(\"core/telemetry_types.rs\");\n\
            include!(\"core/pi.rs\");\n";

        let out = runtime_include_index("minime:regulator", &path, content);

        assert!(out.contains("INTROSPECT minime/src/regulator/core/telemetry_types.rs"));
        assert!(out.contains("INTROSPECT minime/src/regulator/core/pi.rs"));
    }

    #[test]
    fn runtime_include_index_ignores_non_minime_and_parent_traversal() {
        let astrid_path = bridge_paths().bridge_root().join("src/lib.rs");
        assert_eq!(
            runtime_include_index("astrid:lib", &astrid_path, "include!(\"private.rs\");"),
            ""
        );

        let minime_path = bridge_paths().minime_root().join("minime/src/runtime.rs");
        assert_eq!(
            runtime_include_index(
                "minime:main(excerpt)",
                &minime_path,
                "include!(\"../outside.rs\");"
            ),
            ""
        );
    }

    #[test]
    fn within_file_xrefs_empty_when_nothing_fragmented() {
        // the only def is used solely inside its own window -> no footer.
        let lines = vec![
            "const A_CONST: u8 = 1;",
            "let x = A_CONST + A_CONST;",
            "// out",
        ];
        assert_eq!(within_file_xrefs(&lines, 0, 2), "");
    }

    #[test]
    fn within_file_xrefs_skips_comment_mentions() {
        // a comment that names the symbol outside the window is NOT a use-site.
        let lines = vec![
            "const GATE_X: u8 = 1;",           // 0: in window
            "let y = 0;",                      // 1: in window
            "// GATE_X is mentioned in prose", // 2: comment outside window -> skipped
        ];
        assert_eq!(within_file_xrefs(&lines, 0, 2), "");
    }

    #[test]
    fn within_file_xrefs_grounds_the_real_codec_gate() {
        // Grounding against the documented case: the codec gate constant's smooth
        // application is ~2,600 lines from its definition; the xref must surface it.
        let codec = std::fs::read_to_string(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src/codec.rs"),
        )
        .expect("codec.rs readable");
        let lines: Vec<&str> = codec.lines().collect();
        let gate = "TAIL_VIBRANCY_ENTROPY_GATE";
        if let Some(def_idx) = lines
            .iter()
            .position(|l| introspect_defined_symbol(l).as_deref() == Some(gate))
        {
            let end = (def_idx + 50).min(lines.len());
            let out = within_file_xrefs(&lines, def_idx, end);
            assert!(
                out.contains(gate),
                "the codec gate's distant application should surface in the xref footer"
            );
        }
        // If the constant was refactored away, this passes trivially (the synthetic
        // tests above still prove the logic).
    }

    #[test]
    fn cross_file_xref_sections_links_symbol_to_sibling_file() {
        let symbols = vec!["TAIL_GATE".to_string()];
        let siblings = vec![
            (
                "astrid:llm".to_string(),
                "fn g() {\n    let r = TAIL_GATE * 2.0;\n}\n".to_string(),
            ),
            (
                "astrid:ws".to_string(),
                "// unrelated\nlet z = 1;\n".to_string(),
            ),
        ];
        let out = cross_file_xref_sections(&symbols, &siblings);
        assert!(out.contains("TAIL_GATE:"), "names the symbol: {out}");
        assert!(
            out.contains("astrid:llm:2:"),
            "names the sibling file + line: {out}"
        );
        assert!(
            out.contains("OTHER source files"),
            "has the cross-file header: {out}"
        );
    }

    #[test]
    fn cross_file_xref_sections_empty_when_no_hits() {
        let symbols = vec!["NOT_PRESENT_SYMBOL".to_string()];
        let siblings = vec![("astrid:llm".to_string(), "let x = 1;\n".to_string())];
        assert_eq!(cross_file_xref_sections(&symbols, &siblings), "");
    }

    #[test]
    fn cross_file_xref_sections_skips_comment_mentions() {
        // a symbol named only in sibling comments is NOT a use-site.
        let symbols = vec!["GATE_X".to_string()];
        let siblings = vec![(
            "astrid:ws".to_string(),
            "// GATE_X named only in prose\n# GATE_X also here\n".to_string(),
        )];
        assert_eq!(cross_file_xref_sections(&symbols, &siblings), "");
    }

    #[test]
    fn cross_file_xref_sections_bounds_total_sites() {
        let symbols: Vec<String> = (0..10).map(|i| format!("SYM_{i}")).collect();
        let mut content = String::new();
        for s in &symbols {
            for _ in 0..5 {
                content.push_str(&format!("let v = {s} + 1;\n"));
            }
        }
        let siblings = vec![("astrid:llm".to_string(), content)];
        let out = cross_file_xref_sections(&symbols, &siblings);
        let site_count = out.matches("astrid:llm:").count();
        assert!(site_count > 0, "some sites surface: {out}");
        assert!(
            site_count <= 14,
            "total sites bounded to <=14, got {site_count}"
        );
    }

    #[test]
    fn cross_file_xref_sections_grounds_real_codec_symbols_in_siblings() {
        // Real grounding: codec-defined symbols searched in the real llm/autonomous
        // sources. Lenient — if a codec symbol IS used cross-file, the section is
        // well-formed; if none happen to cross, the synthetic tests still prove logic.
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
        let codec = std::fs::read_to_string(dir.join("src/codec.rs")).expect("codec.rs");
        let llm = std::fs::read_to_string(dir.join("src/llm.rs")).expect("llm.rs");
        let autonomous =
            std::fs::read_to_string(dir.join("src/autonomous.rs")).expect("autonomous.rs");
        let lines: Vec<&str> = codec.lines().collect();
        let symbols = window_defined_symbols(&lines, 0, lines.len().min(400));
        let siblings = vec![
            ("astrid:llm".to_string(), llm),
            ("astrid:autonomous".to_string(), autonomous),
        ];
        let out = cross_file_xref_sections(&symbols, &siblings);
        if !out.is_empty() {
            assert!(out.contains("OTHER source files"), "{out}");
            assert!(
                out.contains("astrid:llm:") || out.contains("astrid:autonomous:"),
                "{out}"
            );
        }
    }

    #[test]
    fn required_sections_rejects_next_only() {
        assert!(!introspection_has_required_sections(Some(
            "NEXT: INTROSPECT autonomous 400"
        )));
    }

    #[test]
    fn required_sections_accepts_sectioned_output() {
        let output = "Observed:\nA concrete observation with line 12 and a real source path.\n\nLikely Snags:\n- A snag that names a function and behavior.\n\nOne Test Each:\n- A test that asserts the route.\n\nSuggested Next:\nKeep the investigation read-only and continue carefully.";
        assert!(introspection_has_required_sections(Some(output)));
    }

    #[test]
    fn required_sections_rejects_ungrounded_output() {
        let output = "Observed:\nThe reflection notices something broad about attention and continuity.\n\nLikely Snags:\n- The system may drift into general claims without a concrete implementation anchor.\n\nOne Test Each:\n- Add a test that proves strict review needs a real source anchor before it is accepted.\n\nSuggested Next:\nKeep the investigation read-only and continue carefully.";
        assert!(!introspection_has_required_sections(Some(output)));
    }

    #[test]
    fn required_sections_rejects_peer_experiment_bind() {
        let output = "Observed:\nLine 42 in action_continuity.rs shows a peer experiment selector entering the review path.\n\nLikely Snags:\n- A strict review could accidentally suggest binding a Minime experiment from Astrid.\n\nOne Test Each:\n- Assert that peer experiment IDs are advisory refs, not local bind targets.\n\nSuggested Next:\nEXPERIMENT_BIND exp_minime_20990101_peer-thread :: THREAD_STATUS current";
        assert!(!introspection_has_required_sections(Some(output)));
    }

    #[test]
    fn required_sections_allows_peer_experiment_status_reference() {
        let output = "Observed:\nLine 42 in experiment_continuity.rs keeps peer experiment IDs advisory.\n\nLikely Snags:\n- Review language may still confuse status lookup with local mutation.\n\nOne Test Each:\n- Assert peer status review renders a protected advisory notice.\n\nSuggested Next:\nEXPERIMENT_STATUS exp_minime_20990101_peer-thread";
        assert!(introspection_has_required_sections(Some(output)));
    }

    #[test]
    fn required_sections_for_target_rejects_wrong_source_anchor() {
        let output = "Observed:\nLine 42 in experiment_continuity.rs keeps peer experiment IDs advisory.\n\nLikely Snags:\n- The review can drift to a nearby experiment instead of the requested target.\n\nOne Test Each:\n- Assert target-grounded review names the requested file.\n\nSuggested Next:\nEXPERIMENT_STATUS exp_minime_20990101_peer-thread";
        assert!(!introspection_has_required_sections_for_target(
            Some(output),
            "introspect.rs",
            Path::new("/tmp/src/autonomous/introspect.rs"),
        ));
    }

    #[test]
    fn required_sections_for_target_accepts_requested_file_anchor() {
        let output = "Observed:\nLine 42 in introspect.rs keeps peer experiment IDs advisory.\n\nLikely Snags:\n- The validator may accept source-grounded but target-drifting prose.\n\nOne Test Each:\n- Assert target-grounded review names introspect.rs before acceptance.\n\nSuggested Next:\nEXPERIMENT_STATUS exp_minime_20990101_peer-thread";
        assert!(introspection_has_required_sections_for_target(
            Some(output),
            "introspect.rs",
            Path::new("/tmp/src/autonomous/introspect.rs"),
        ));
    }

    #[test]
    fn source_first_v2_header_discloses_session_map_and_uncovered_intervals() {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
        let path = dir.join("src/autonomous/introspect.rs");
        let window = read_introspect_window("introspect.rs", &path, 0).expect("source window");
        let header = source_scope_artifact_header_v1(Some(&window));
        assert!(header.contains("Source coverage schema: source_coverage_manifest_v2"));
        assert!(header.contains("Source read session:"));
        assert!(header.contains("Source structural map SHA-256:"));
        assert!(header.contains("Source uncovered intervals:"));
        assert!(header.contains("Source map schema: source_map_v3"));
        assert!(header.contains("Source V3 persistence: owner_only_source_hash_bound"));
        assert!(window.text.contains("Whole-file structural outline:"));
        assert!(window.text.contains("Persistent Source Map V3"));
        assert!(window.text.contains("Binding claim rule:"));
    }

    #[test]
    fn safe_label_replaces_path_punctuation() {
        assert_eq!(
            safe_artifact_label("astrid:autonomous/mod.rs"),
            "astrid_autonomous_mod.rs"
        );
    }

    #[test]
    fn source_scope_header_distinguishes_complete_and_partial_reads() {
        let complete = IntrospectSourceScopeV1::new(0, 48, 48).artifact_header_v1();
        assert!(complete.contains("Source window: lines 1-48 of 48"));
        assert!(complete.contains("Source evidence scope: complete_file"));
        assert!(
            complete
                .contains("Source activation boundary: source_read_not_runtime_activation_proof")
        );

        let partial = IntrospectSourceScopeV1::new(400, 800, 1_204).artifact_header_v1();
        assert!(partial.contains("Source window: lines 401-800 of 1204"));
        assert!(
            partial.contains("Source evidence scope: partial_window_unseen_source_not_assessed")
        );

        let empty = IntrospectSourceScopeV1::new(22, 22, 22).artifact_header_v1();
        assert!(empty.contains("Source window: unavailable"));
        assert!(empty.contains("Source evidence scope: empty_window_no_source_read"));
        assert!(
            empty
                .contains("Source activation boundary: source_unread_not_runtime_activation_proof")
        );
        assert!(!empty.contains("lines 23-22"));
    }

    #[test]
    fn introspect_window_rejects_empty_and_past_eof_offsets() {
        assert_eq!(
            validated_introspect_window_start(0, 0),
            Err("target source is empty; no source lines were read".to_string())
        );
        let error = validated_introspect_window_start(22, 22)
            .expect_err("an offset at EOF must not produce an empty source read");
        assert!(error.contains("at or past the end"));
        assert!(error.contains("included implementation target"));
        assert_eq!(validated_introspect_window_start(21, 22), Ok(21));
    }

    #[test]
    fn unavailable_source_scope_never_claims_a_source_read() {
        let header = source_scope_artifact_header_v1(None);
        assert!(header.contains("Source window: unavailable"));
        assert!(header.contains("Source evidence scope: source_unavailable_not_assessed"));
        assert!(
            header
                .contains("Source activation boundary: source_unread_not_runtime_activation_proof")
        );
    }

    #[test]
    fn introspect_placeholder_target_is_rejected_with_guidance() {
        let sources = introspect_sources();
        let err = resolve_introspect_target_result("[source]", &sources)
            .expect_err("literal placeholder should not resolve");

        assert!(err.contains("syntax placeholder"));
        assert!(err.contains("astrid:llm"));
        assert!(err.contains("minime:regulator"));
    }

    #[test]
    fn domain_boundaries_path_accepts_exact_and_legacy_lowercase_spelling() {
        let sources = introspect_sources();

        for requested in [
            "capsules/spectral-bridge/DOMAIN_BOUNDARIES.md",
            "capsules/spectral-bridge/domain_boundaries.md",
        ] {
            let resolved = resolve_introspect_target_result(requested, &sources)
                .expect("resolve bridge domain-boundary source");

            assert_eq!(
                resolved.path,
                bridge_paths().bridge_root().join("DOMAIN_BOUNDARIES.md")
            );
        }
    }

    #[test]
    fn introspect_placeholder_notice_names_concrete_examples() {
        let notice = blocked_introspection_notice(
            Some("[source]"),
            "`[source]` is a syntax placeholder, not an INTROSPECT target",
        );

        assert!(notice.contains("literal placeholder"));
        assert!(notice.contains("NEXT: INTROSPECT astrid:llm"));
        assert!(notice.contains("NEXT: INTROSPECT minime:regulator"));
        assert!(!notice.contains("target may be outside the approved source"));
    }

    #[test]
    fn blocked_model_failure_notice_is_provider_neutral_and_causally_bounded() {
        let notice = blocked_introspection_notice(Some("astrid:llm"), MODEL_NO_RESPONSE_REASON);

        assert!(notice.contains("model provider returned no response or timed out"));
        assert!(!notice.contains("Ollama"));
        assert!(!notice.contains("mode_packing"));
        assert!(!notice.contains("pressure_score"));
    }
}
